# PhoneDock - Database Structure

## Database: MongoDB
**Database Name:** `phonedock`

---

## Collections

### 1. **admins**
Admin user accounts for authentication

```javascript
{
  _id: ObjectId,
  username: String (required, unique),
  email: String (required, unique),
  password: String (required, hashed with bcryptjs),
  role: String (enum: ['admin', 'superadmin'], default: 'admin'),
  createdAt: Date (default: now)
}
```

**Indexes:**
- `username`: unique
- `email`: unique

**Sample Document:**
```json
{
  "_id": "507f1f77bcf86cd799439011",
  "username": "admin",
  "email": "admin@phonedock.com",
  "password": "$2a$10$xyz...",
  "role": "superadmin",
  "createdAt": "2025-07-12T00:00:00.000Z"
}
```

---

### 2. **brands**
Smartphone manufacturers

```javascript
{
  _id: ObjectId,
  name: String (required, unique),
  slug: String (required, unique),
  logo: String,
  country: String,
  description: String,
  createdAt: Date (default: now)
}
```

**Indexes:**
- `name`: unique
- `slug`: unique

**Sample Document:**
```json
{
  "_id": "507f1f77bcf86cd799439012",
  "name": "Samsung",
  "slug": "samsung",
  "logo": "https://example.com/samsung-logo.png",
  "country": "South Korea",
  "description": "Global leader in electronics and smartphones",
  "createdAt": "2025-07-12T00:00:00.000Z"
}
```

---

### 3. **phones**
Smartphone details with complete specifications

```javascript
{
  _id: ObjectId,
  brandId: ObjectId (ref: 'Brand', required),
  brandName: String,
  model: String (required),
  slug: String (required, unique),
  releaseDate: Date,
  price: Number (default: 0),
  ptaApproved: Boolean (default: false),
  featured: Boolean (default: false),
  trending: Boolean (default: false),
  upcoming: Boolean (default: false),
  images: [String],
  
  specs: {
    display: {
      size: String,
      resolution: String,
      type: String,
      refreshRate: String,
      protection: String
    },
    processor: {
      chipset: String,
      cpu: String,
      gpu: String
    },
    memory: {
      ram: String,
      storage: String,
      cardSlot: String
    },
    camera: {
      main: String,
      features: String,
      video: String,
      selfie: String
    },
    battery: {
      capacity: String,
      charging: String,
      wireless: Boolean
    },
    connectivity: {
      network: String,
      wifi: String,
      bluetooth: String,
      nfc: Boolean,
      usb: String
    },
    body: {
      dimensions: String,
      weight: String,
      build: String,
      sim: String
    },
    features: {
      fingerprint: String,
      faceUnlock: Boolean,
      sensors: String,
      colors: [String]
    },
    os: {
      name: String,
      version: String
    }
  },
  
  ratings: {
    overall: Number (default: 0, 0-10),
    performance: Number (default: 0, 0-10),
    camera: Number (default: 0, 0-10),
    battery: Number (default: 0, 0-10),
    display: Number (default: 0, 0-10),
    value: Number (default: 0, 0-10)
  },
  
  review: {
    pros: [String],
    cons: [String],
    summary: String
  },
  
  benchmarks: {
    antutu: Number,
    geekbenchSingle: Number,
    geekbenchMulti: Number
  },
  
  createdAt: Date (default: now),
  updatedAt: Date (default: now)
}
```

**Indexes:**
- `slug`: unique
- `brandId`: 1
- `price`: 1
- `trending`: 1
- `featured`: 1

**Sample Document:** (See phones in database)

---

### 4. **news**
News articles and updates

```javascript
{
  _id: ObjectId,
  title: String (required),
  slug: String (required, unique),
  content: String (required),
  excerpt: String,
  image: String,
  category: String (enum: ['launch', 'rumor', 'review', 'update', 'other'], default: 'other'),
  author: String,
  published: Boolean (default: true),
  createdAt: Date (default: now)
}
```

**Indexes:**
- `slug`: unique

---

### 5. **videos** (NEW)
YouTube videos for reviews and content

```javascript
{
  _id: ObjectId,
  title: String (required),
  youtubeId: String (required),
  thumbnail: String,
  phoneId: ObjectId (ref: 'Phone'),
  category: String (enum: ['review', 'unboxing', 'comparison', 'tutorial', 'news'], default: 'review'),
  channel: String (default: 'Shams Tech'),
  views: Number (default: 0),
  published: Boolean (default: true),
  createdAt: Date (default: now)
}
```

**Indexes:**
- `phoneId`: 1
- `published`: 1

---

### 6. **sponsors** (NEW)
Sponsors and advertisement management

```javascript
{
  _id: ObjectId,
  name: String (required),
  logo: String (required),
  website: String,
  position: String (enum: ['homepage-top', 'homepage-sidebar', 'phone-detail', 'sidebar-sticky'], required),
  bannerImage: String,
  link: String,
  active: Boolean (default: true),
  priority: Number (default: 0),
  impressions: Number (default: 0),
  clicks: Number (default: 0),
  startDate: Date,
  endDate: Date,
  createdAt: Date (default: now)
}
```

**Indexes:**
- `active`: 1
- `position`: 1
- `priority`: -1

---

### 7. **benchmarks** (NEW)
Detailed benchmark and test results

```javascript
{
  _id: ObjectId,
  phoneId: ObjectId (ref: 'Phone', required),
  
  antutu: {
    overall: Number,
    cpu: Number,
    gpu: Number,
    mem: Number,
    ux: Number
  },
  
  geekbench: {
    singleCore: Number,
    multiCore: Number,
    compute: Number
  },
  
  gaming: {
    pubgFps: Number,
    codmFps: Number,
    genshinFps: Number,
    temperature: Number,
    throttling: String
  },
  
  battery: {
    capacity: String,
    videoPlayback: String,
    gaming: String,
    charging: {
      time0to50: String,
      time0to100: String,
      wattage: String
    }
  },
  
  camera: {
    dxoMark: Number,
    photo: Number,
    video: Number,
    zoom: Number,
    samples: [String]
  },
  
  display: {
    brightness: String,
    colorAccuracy: String,
    touchResponse: String
  },
  
  createdAt: Date (default: now)
}
```

**Indexes:**
- `phoneId`: 1

---

## Current Database Statistics

**As of 2025-07-12:**

- **admins:** 1 document
- **brands:** 8 documents
- **phones:** 4 documents
- **news:** 0 documents
- **videos:** 0 documents
- **sponsors:** 0 documents
- **benchmarks:** 0 documents

**Total Collections:** 7
**Total Documents:** 13

---

## Relationships

```
brands (1) ----< (N) phones
phones (1) ----< (1) benchmarks
phones (1) ----< (N) videos
```

---

## Query Patterns

### Common Queries:

1. **Get all phones by brand:**
```javascript
Phone.find({ brandId: brandId })
```

2. **Get trending phones:**
```javascript
Phone.find({ trending: true }).limit(6)
```

3. **Get best camera phones:**
```javascript
Phone.find().sort({ 'ratings.camera': -1 }).limit(6)
```

4. **Search phones:**
```javascript
Phone.find({
  $or: [
    { model: { $regex: query, $options: 'i' } },
    { brandName: { $regex: query, $options: 'i' } }
  ]
})
```

5. **Get phone with benchmark:**
```javascript
const phone = await Phone.findOne({ slug });
const benchmark = await Benchmark.findOne({ phoneId: phone._id });
```

---

## Backup & Restore

**Backup Location:** `/app/backups/`

**Backup Format:** `.tar.gz` containing JSON exports

**Backup Script:**
```bash
bash /app/scripts/backup.sh
```

**Restore Script:**
```bash
bash /app/scripts/restore.sh /app/backups/backup_file.tar.gz
```

---

## Database Connection

**Connection String:** `MONGO_URL` environment variable
**Database Name:** `DB_NAME` environment variable (default: 'phonedock')
**Connection File:** `/app/lib/db.js`

---

**Last Updated:** 2025-07-12
