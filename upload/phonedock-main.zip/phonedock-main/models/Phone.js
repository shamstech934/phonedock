import mongoose from 'mongoose';

const PhoneSchema = new mongoose.Schema({
  brandId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Brand',
    required: true,
  },
  brandName: String,
  model: {
    type: String,
    required: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
  },
  releaseDate: Date,
  launchDate: Date,
  ptaApprovalDate: Date,
  marketAvailability: String,
  price: {
    type: Number,
    default: 0,
  },
  ptaApproved: {
    type: Boolean,
    default: false,
  },
  featured: {
    type: Boolean,
    default: false,
  },
  trending: {
    type: Boolean,
    default: false,
  },
  upcoming: {
    type: Boolean,
    default: false,
  },
  images: [String],
  
  // Specifications
  specs: {
    display: {
      size: String,
      resolution: String,
      type: String,
      refreshRate: String,
      protection: String,
    },
    processor: {
      chipset: String,
      cpu: String,
      gpu: String,
    },
    memory: {
      ram: String,
      storage: String,
      cardSlot: String,
    },
    camera: {
      main: String,
      mainSensor: String,
      aperture: String,
      ois: Boolean,
      eis: Boolean,
      zoom: String,
      features: String,
      video: String,
      selfie: String,
      selfieSensor: String,
    },
    battery: {
      capacity: String,
      charging: String,
      wireless: Boolean,
    },
    connectivity: {
      network: String,
      wifi: String,
      bluetooth: String,
      nfc: Boolean,
      usb: String,
    },
    body: {
      dimensions: String,
      weight: String,
      build: String,
      sim: String,
      sarValue: String,
    },
    features: {
      fingerprint: String,
      faceUnlock: Boolean,
      sensors: String,
      colors: [String],
      boxContents: String,
    },
    os: {
      name: String,
      version: String,
    },
  },
  
  // Ratings
  ratings: {
    overall: { type: Number, default: 0 },
    performance: { type: Number, default: 0 },
    camera: { type: Number, default: 0 },
    battery: { type: Number, default: 0 },
    display: { type: Number, default: 0 },
    value: { type: Number, default: 0 },
  },
  
  // Review
  review: {
    pros: [String],
    cons: [String],
    summary: String,
  },
  
  // Benchmarks
  benchmarks: {
    antutu: Number,
    geekbenchSingle: Number,
    geekbenchMulti: Number,
  },
  
  // Gaming Performance
  gaming: {
    pubgFps: String,
    codMobileFps: String,
    genshinFps: String,
  },
  
  // Battery Tests
  batteryTests: {
    videoPlayback: String,
    gaming: String,
    browsing: String,
  },
  
  // Camera Samples
  cameraSamples: {
    dayPhotos: [String],
    nightPhotos: [String],
    videoSamples: [String],
  },
  
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Indexes for performance (slug already unique in schema, no need to index again)
PhoneSchema.index({ brandId: 1 });
PhoneSchema.index({ price: 1 });
PhoneSchema.index({ trending: 1 });
PhoneSchema.index({ featured: 1 });
PhoneSchema.index({ 'specs.processor.chipset': 1 });
PhoneSchema.index({ 'ratings.overall': -1 });
PhoneSchema.index({ createdAt: -1 });

export default mongoose.models.Phone || mongoose.model('Phone', PhoneSchema);