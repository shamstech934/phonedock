import mongoose from 'mongoose';

const ActivityLogSchema = new mongoose.Schema({
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
    required: true,
  },
  adminEmail: {
    type: String,
    required: true,
  },
  action: {
    type: String,
    required: true,
    enum: ['CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT'],
  },
  resource: {
    type: String,
    required: true,
    enum: ['Phone', 'Brand', 'News', 'Video', 'Sponsor', 'Admin'],
  },
  resourceId: {
    type: String,
  },
  resourceName: {
    type: String,
  },
  changes: {
    type: Object,
    default: {},
  },
  ipAddress: {
    type: String,
  },
  userAgent: {
    type: String,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
});

// Index for faster queries
ActivityLogSchema.index({ adminId: 1, timestamp: -1 });
ActivityLogSchema.index({ resource: 1, timestamp: -1 });
ActivityLogSchema.index({ timestamp: -1 });

export default mongoose.models.ActivityLog || mongoose.model('ActivityLog', ActivityLogSchema);
