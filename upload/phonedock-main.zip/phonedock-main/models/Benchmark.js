import mongoose from 'mongoose';

const BenchmarkSchema = new mongoose.Schema({
  phoneId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Phone',
    required: true,
  },
  antutu: {
    overall: Number,
    cpu: Number,
    gpu: Number,
    mem: Number,
    ux: Number,
  },
  geekbench: {
    singleCore: Number,
    multiCore: Number,
    compute: Number,
  },
  gaming: {
    pubgFps: Number,
    codmFps: Number,
    genshinFps: Number,
    temperature: Number,
    throttling: String,
  },
  battery: {
    capacity: String,
    videoPlayback: String,
    gaming: String,
    charging: {
      time0to50: String,
      time0to100: String,
      wattage: String,
    },
  },
  camera: {
    dxoMark: Number,
    photo: Number,
    video: Number,
    zoom: Number,
    samples: [String], // Array of image URLs
  },
  display: {
    brightness: String,
    colorAccuracy: String,
    touchResponse: String,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

BenchmarkSchema.index({ phoneId: 1 });

export default mongoose.models.Benchmark || mongoose.model('Benchmark', BenchmarkSchema);