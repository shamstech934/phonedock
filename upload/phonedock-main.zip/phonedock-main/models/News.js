import mongoose from 'mongoose';

const NewsSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
  },
  content: {
    type: String,
    required: true,
  },
  excerpt: String,
  image: String,
  category: {
    type: String,
    enum: ['launch', 'rumor', 'review', 'update', 'other'],
    default: 'other',
  },
  author: String,
  published: {
    type: Boolean,
    default: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.models.News || mongoose.model('News', NewsSchema);