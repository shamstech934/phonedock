import mongoose from 'mongoose';

const SponsorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  logo: {
    type: String,
    required: true,
  },
  website: String,
  position: {
    type: String,
    enum: ['homepage-top', 'homepage-sidebar', 'phone-detail', 'sidebar-sticky'],
    required: true,
  },
  bannerImage: String,
  link: String,
  active: {
    type: Boolean,
    default: true,
  },
  priority: {
    type: Number,
    default: 0,
  },
  impressions: {
    type: Number,
    default: 0,
  },
  clicks: {
    type: Number,
    default: 0,
  },
  startDate: Date,
  endDate: Date,
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.models.Sponsor || mongoose.model('Sponsor', SponsorSchema);