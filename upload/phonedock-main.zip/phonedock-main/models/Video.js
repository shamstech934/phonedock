import mongoose from 'mongoose';

const VideoSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  youtubeId: {
    type: String,
    required: true,
  },
  thumbnail: String,
  phoneId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Phone',
  },
  category: {
    type: String,
    enum: ['review', 'unboxing', 'comparison', 'tutorial', 'news'],
    default: 'review',
  },
  channel: {
    type: String,
    default: 'Shams Tech',
  },
  views: {
    type: Number,
    default: 0,
  },
  published: {
    type: Boolean,
    default: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.models.Video || mongoose.model('Video', VideoSchema);