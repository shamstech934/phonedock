// Seed script to populate PhoneDock with sample data
const mongoose = require('mongoose');

const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017';
const DB_NAME = process.env.DB_NAME || 'phonedock';

const BrandSchema = new mongoose.Schema({
  name: String,
  slug: String,
  logo: String,
  country: String,
  description: String,
  createdAt: { type: Date, default: Date.now },
});

const PhoneSchema = new mongoose.Schema({
  brandId: mongoose.Schema.Types.ObjectId,
  brandName: String,
  model: String,
  slug: String,
  releaseDate: Date,
  price: Number,
  ptaApproved: Boolean,
  featured: Boolean,
  trending: Boolean,
  upcoming: Boolean,
  images: [String],
  specs: Object,
  ratings: Object,
  review: Object,
  benchmarks: Object,
  createdAt: { type: Date, default: Date.now },
});

const Brand = mongoose.model('Brand', BrandSchema);
const Phone = mongoose.model('Phone', PhoneSchema);

const sampleBrands = [
  { name: 'Samsung', slug: 'samsung', country: 'South Korea', description: 'Global leader in smartphones and electronics' },
  { name: 'Apple', slug: 'apple', country: 'USA', description: 'Premium smartphones and technology' },
  { name: 'Xiaomi', slug: 'xiaomi', country: 'China', description: 'Value-focused smartphones' },
  { name: 'OnePlus', slug: 'oneplus', country: 'China', description: 'Flagship killer smartphones' },
  { name: 'Realme', slug: 'realme', country: 'China', description: 'Budget and mid-range smartphones' },
  { name: 'Vivo', slug: 'vivo', country: 'China', description: 'Camera-focused smartphones' },
  { name: 'Oppo', slug: 'oppo', country: 'China', description: 'Stylish mid-range smartphones' },
  { name: 'Google', slug: 'google', country: 'USA', description: 'Pure Android experience' },
];

async function seed() {
  try {
    console.log('Connecting to MongoDB...');
    await mongoose.connect(`${MONGO_URL}/${DB_NAME}`);
    console.log('Connected!');

    // Clear existing data
    console.log('Clearing existing data...');
    await Brand.deleteMany({});
    await Phone.deleteMany({});

    // Insert brands
    console.log('Inserting brands...');
    const brands = await Brand.insertMany(sampleBrands);
    console.log(`Inserted ${brands.length} brands`);

    // Get brand IDs
    const samsung = brands.find(b => b.slug === 'samsung');
    const apple = brands.find(b => b.slug === 'apple');
    const xiaomi = brands.find(b => b.slug === 'xiaomi');
    const oneplus = brands.find(b => b.slug === 'oneplus');

    // Sample phones
    const samplePhones = [
      {
        brandId: samsung._id,
        brandName: 'Samsung',
        model: 'Galaxy S24 Ultra',
        slug: 'samsung-galaxy-s24-ultra',
        releaseDate: new Date('2024-01-24'),
        price: 419999,
        ptaApproved: true,
        featured: true,
        trending: true,
        images: ['https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400'],
        specs: {
          display: {
            size: '6.8 inches',
            resolution: '1440 x 3120 pixels',
            type: 'Dynamic AMOLED 2X',
            refreshRate: '120Hz',
            protection: 'Gorilla Glass Armor',
          },
          processor: {
            chipset: 'Snapdragon 8 Gen 3',
            cpu: 'Octa-core (1x3.3 GHz + 3x3.2 GHz + 2x3.0 GHz + 2x2.3 GHz)',
            gpu: 'Adreno 750',
          },
          memory: {
            ram: '12GB',
            storage: '256GB/512GB/1TB',
            cardSlot: 'No',
          },
          camera: {
            main: '200MP + 50MP + 10MP + 12MP',
            features: 'LED flash, auto-HDR, panorama',
            video: '8K@24/30fps, 4K@30/60fps',
            selfie: '12MP',
          },
          battery: {
            capacity: '5000 mAh',
            charging: '45W wired, 15W wireless',
            wireless: true,
          },
          connectivity: {
            network: '5G',
            wifi: 'Wi-Fi 7',
            bluetooth: '5.3',
            nfc: true,
            usb: 'Type-C 3.2',
          },
          body: {
            dimensions: '162.3 x 79 x 8.6 mm',
            weight: '232g',
            build: 'Titanium frame, Gorilla Glass',
            sim: 'Dual SIM',
          },
          features: {
            fingerprint: 'Under display, ultrasonic',
            faceUnlock: true,
            sensors: 'Accelerometer, gyro, proximity, compass, barometer',
            colors: ['Titanium Black', 'Titanium Gray', 'Titanium Violet', 'Titanium Yellow'],
          },
          os: {
            name: 'Android',
            version: '14, One UI 6.1',
          },
        },
        ratings: {
          overall: 9.2,
          performance: 9.5,
          camera: 9.4,
          battery: 8.8,
          display: 9.6,
          value: 8.5,
        },
        review: {
          pros: [
            'Excellent display quality',
            'Top-tier performance',
            'Versatile camera system',
            'S Pen included',
            'Premium build quality',
          ],
          cons: [
            'Expensive',
            'No microSD card slot',
            'Heavy device',
          ],
          summary: 'The Galaxy S24 Ultra is Samsung\'s flagship powerhouse with an incredible display, top-notch cameras, and the iconic S Pen. It\'s the best Android phone for power users.',
        },
        benchmarks: {
          antutu: 1850000,
          geekbenchSingle: 2200,
          geekbenchMulti: 6800,
        },
      },
      {
        brandId: apple._id,
        brandName: 'Apple',
        model: 'iPhone 15 Pro Max',
        slug: 'iphone-15-pro-max',
        releaseDate: new Date('2023-09-22'),
        price: 459999,
        ptaApproved: true,
        featured: true,
        trending: true,
        images: ['https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400'],
        specs: {
          display: {
            size: '6.7 inches',
            resolution: '1290 x 2796 pixels',
            type: 'LTPO Super Retina XDR OLED',
            refreshRate: '120Hz',
            protection: 'Ceramic Shield',
          },
          processor: {
            chipset: 'A17 Pro',
            cpu: 'Hexa-core',
            gpu: 'Apple GPU (6-core)',
          },
          memory: {
            ram: '8GB',
            storage: '256GB/512GB/1TB',
            cardSlot: 'No',
          },
          camera: {
            main: '48MP + 12MP + 12MP',
            features: 'Dual-LED dual-tone flash, HDR',
            video: '4K@24/25/30/60fps, ProRes',
            selfie: '12MP',
          },
          battery: {
            capacity: '4441 mAh',
            charging: '20W wired, 15W MagSafe wireless',
            wireless: true,
          },
          connectivity: {
            network: '5G',
            wifi: 'Wi-Fi 6E',
            bluetooth: '5.3',
            nfc: true,
            usb: 'Type-C 3.2',
          },
          body: {
            dimensions: '159.9 x 76.7 x 8.3 mm',
            weight: '221g',
            build: 'Titanium frame, Ceramic Shield glass',
            sim: 'Dual eSIM',
          },
          features: {
            fingerprint: 'No',
            faceUnlock: true,
            sensors: 'Face ID, accelerometer, gyro, proximity, compass, barometer',
            colors: ['Natural Titanium', 'Blue Titanium', 'White Titanium', 'Black Titanium'],
          },
          os: {
            name: 'iOS',
            version: '17',
          },
        },
        ratings: {
          overall: 9.0,
          performance: 9.5,
          camera: 9.2,
          battery: 8.5,
          display: 9.3,
          value: 8.0,
        },
        review: {
          pros: [
            'Excellent ecosystem integration',
            'Premium titanium build',
            'Outstanding video recording',
            'Long-term software support',
            'USB-C finally',
          ],
          cons: [
            'Very expensive',
            'No fast charging included',
            'Limited customization',
          ],
          summary: 'The iPhone 15 Pro Max brings titanium design, USB-C, and powerful performance. It\'s the ultimate iPhone for those invested in Apple\'s ecosystem.',
        },
        benchmarks: {
          antutu: 1640000,
          geekbenchSingle: 2930,
          geekbenchMulti: 7250,
        },
      },
      {
        brandId: xiaomi._id,
        brandName: 'Xiaomi',
        model: 'Redmi Note 13 Pro',
        slug: 'redmi-note-13-pro',
        price: 74999,
        ptaApproved: true,
        trending: true,
        images: ['https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400'],
        specs: {
          display: {
            size: '6.67 inches',
            resolution: '1080 x 2400 pixels',
            type: 'AMOLED',
            refreshRate: '120Hz',
            protection: 'Gorilla Glass Victus',
          },
          processor: {
            chipset: 'Snapdragon 7s Gen 2',
            cpu: 'Octa-core',
            gpu: 'Adreno 710',
          },
          memory: {
            ram: '8GB/12GB',
            storage: '256GB',
            cardSlot: 'microSD',
          },
          camera: {
            main: '200MP + 8MP + 2MP',
            features: 'LED flash, HDR, panorama',
            video: '4K@30fps, 1080p@60fps',
            selfie: '16MP',
          },
          battery: {
            capacity: '5000 mAh',
            charging: '67W wired',
            wireless: false,
          },
          connectivity: {
            network: '5G',
            wifi: 'Wi-Fi 6',
            bluetooth: '5.2',
            nfc: true,
            usb: 'Type-C 2.0',
          },
          body: {
            dimensions: '161.2 x 74.2 x 7.98 mm',
            weight: '187g',
            build: 'Glass front, plastic frame',
            sim: 'Dual SIM',
          },
          features: {
            fingerprint: 'Side-mounted',
            faceUnlock: true,
            sensors: 'Accelerometer, gyro, proximity, compass',
            colors: ['Midnight Black', 'Ocean Teal', 'Coral Purple'],
          },
          os: {
            name: 'Android',
            version: '13, MIUI 14',
          },
        },
        ratings: {
          overall: 8.3,
          performance: 8.0,
          camera: 8.5,
          battery: 8.8,
          display: 8.5,
          value: 9.2,
        },
        review: {
          pros: [
            'Excellent value for money',
            'Great camera system',
            'Fast charging',
            'Good display',
            'Expandable storage',
          ],
          cons: [
            'Plastic build',
            'Ads in MIUI',
            'Average gaming performance',
          ],
          summary: 'The Redmi Note 13 Pro offers flagship features at a mid-range price, making it one of the best value phones in Pakistan.',
        },
        benchmarks: {
          antutu: 620000,
          geekbenchSingle: 920,
          geekbenchMulti: 2700,
        },
      },
      {
        brandId: oneplus._id,
        brandName: 'OnePlus',
        model: 'OnePlus 12',
        slug: 'oneplus-12',
        price: 249999,
        ptaApproved: true,
        featured: true,
        images: ['https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400'],
        specs: {
          display: {
            size: '6.82 inches',
            resolution: '1440 x 3168 pixels',
            type: 'LTPO AMOLED',
            refreshRate: '120Hz',
            protection: 'Gorilla Glass Victus 2',
          },
          processor: {
            chipset: 'Snapdragon 8 Gen 3',
            cpu: 'Octa-core',
            gpu: 'Adreno 750',
          },
          memory: {
            ram: '12GB/16GB',
            storage: '256GB/512GB',
            cardSlot: 'No',
          },
          camera: {
            main: '50MP + 64MP + 48MP',
            features: 'Hasselblad, LED flash, HDR',
            video: '8K@24fps, 4K@60fps',
            selfie: '32MP',
          },
          battery: {
            capacity: '5400 mAh',
            charging: '100W wired, 50W wireless',
            wireless: true,
          },
          connectivity: {
            network: '5G',
            wifi: 'Wi-Fi 7',
            bluetooth: '5.4',
            nfc: true,
            usb: 'Type-C 3.2',
          },
          body: {
            dimensions: '164.3 x 75.8 x 9.2 mm',
            weight: '220g',
            build: 'Glass front and back, aluminum frame',
            sim: 'Dual SIM',
          },
          features: {
            fingerprint: 'Under display, optical',
            faceUnlock: true,
            sensors: 'Accelerometer, gyro, proximity, compass',
            colors: ['Flowy Emerald', 'Silky Black'],
          },
          os: {
            name: 'Android',
            version: '14, OxygenOS 14',
          },
        },
        ratings: {
          overall: 8.8,
          performance: 9.3,
          camera: 8.6,
          battery: 9.0,
          display: 9.2,
          value: 8.7,
        },
        review: {
          pros: [
            'Blazing fast charging',
            'Excellent performance',
            'Great display',
            'Clean OxygenOS',
            'Good battery life',
          ],
          cons: [
            'No microSD slot',
            'Average camera zoom',
            'Slightly heavy',
          ],
          summary: 'OnePlus 12 brings flagship performance with incredibly fast charging and a beautiful display, maintaining the brand\'s flagship killer reputation.',
        },
        benchmarks: {
          antutu: 1820000,
          geekbenchSingle: 2180,
          geekbenchMulti: 6750,
        },
      },
    ];

    // Insert phones
    console.log('Inserting phones...');
    const phones = await Phone.insertMany(samplePhones);
    console.log(`Inserted ${phones.length} phones`);

    console.log('\n✅ Seed completed successfully!');
    console.log(`\nCreated:\n- ${brands.length} brands\n- ${phones.length} phones`);
    
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding database:', error);
    mongoose.connection.close();
    process.exit(1);
  }
}

seed();
