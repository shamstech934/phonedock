#!/bin/bash
# PhoneDock Database Backup Script

BACKUP_DIR="/app/backups"
DATE=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="phonedock_backup_${DATE}"

# Create backup directory
mkdir -p $BACKUP_DIR

echo "Starting PhoneDock database backup..."
echo "Backup name: $BACKUP_NAME"

# Export all collections to JSON
echo "Exporting brands..."
mongoexport --db=phonedock --collection=brands --out=$BACKUP_DIR/${BACKUP_NAME}_brands.json --jsonArray

echo "Exporting phones..."
mongoexport --db=phonedock --collection=phones --out=$BACKUP_DIR/${BACKUP_NAME}_phones.json --jsonArray

echo "Exporting admins..."
mongoexport --db=phonedock --collection=admins --out=$BACKUP_DIR/${BACKUP_NAME}_admins.json --jsonArray

echo "Exporting news..."
mongoexport --db=phonedock --collection=news --out=$BACKUP_DIR/${BACKUP_NAME}_news.json --jsonArray

# Create a compressed archive
echo "Creating compressed backup..."
cd $BACKUP_DIR
tar -czf ${BACKUP_NAME}.tar.gz ${BACKUP_NAME}_*.json
rm ${BACKUP_NAME}_*.json

echo "✅ Backup completed successfully!"
echo "Backup file: $BACKUP_DIR/${BACKUP_NAME}.tar.gz"
echo "Backup size: $(du -h $BACKUP_DIR/${BACKUP_NAME}.tar.gz | cut -f1)"

ls -lh $BACKUP_DIR/
