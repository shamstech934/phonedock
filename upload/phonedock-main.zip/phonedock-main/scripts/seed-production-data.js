// PhoneDock - Production Data Seeding Script
// Run: node scripts/seed-production-data.js

import mongoose from 'mongoose';
import Brand from '../models/Brand.js';
import Phone from '../models/Phone.js';

const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/phonedock';

// Brand Logos
const brandLogos = {
  'Apple': 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg',
  'Samsung': 'https://upload.wikimedia.org/wikipedia/commons/2/24/Samsung_Logo.svg',
  'OnePlus': 'https://upload.wikimedia.org/wikipedia/commons/c/c9/OnePlus_logo.svg',
  'Google': 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg',
  'Xiaomi': 'https://upload.wikimedia.org/wikipedia/commons/2/29/Xiaomi_logo.svg',
  'Oppo': 'https://upload.wikimedia.org/wikipedia/commons/8/89/Oppo_logo_2019.svg',
  'Vivo': 'https://upload.wikimedia.org/wikipedia/commons/e/e7/Vivo_logo_2019.svg',
  'Realme': 'https://upload.wikimedia.org/wikipedia/commons/9/91/Realme_logo.svg',
};

// Brands Data
const brandsData = [
  { name: 'Apple', slug: 'apple', logo: brandLogos.Apple, country: 'USA', description: 'Premium smartphones with iOS ecosystem' },
  { name: 'Samsung', slug: 'samsung', logo: brandLogos.Samsung, country: 'South Korea', description: 'Galaxy series - Innovation leader' },
  { name: 'OnePlus', slug: 'oneplus', logo: brandLogos.OnePlus, country: 'China', description: 'Never Settle - Flagship killer' },
  { name: 'Google', slug: 'google', logo: brandLogos.Google, country: 'USA', description: 'Pixel series - Pure Android experience' },
  { name: 'Xiaomi', slug: 'xiaomi', logo: brandLogos.Xiaomi, country: 'China', description: 'Best value for money' },
  { name: 'Oppo', slug: 'oppo', logo: brandLogos.Oppo, country: 'China', description: 'Camera innovation leader' },
  { name: 'Vivo', slug: 'vivo', logo: brandLogos.Vivo, country: 'China', description: 'Style and performance' },
  { name: 'Realme', slug: 'realme', logo: brandLogos.Realme, country: 'China', description: 'Dare to leap - Youth brand' },
];

// Phones Data with Pakistan Prices
const phonesData = [
  {
    brandName: 'Apple',
    model: 'iPhone 15 Pro Max',
    slug: 'iphone-15-pro-max',
    price: 569999,
    ptaApproved: true,
    featured: true,
    trending: true,
    images: ['https://fdn2.gsmarena.com/vv/bigpic/apple-iphone-15-pro-max.jpg'],
    releaseDate: new Date('2023-09-22'),
    launchDate: new Date('2023-09-12'),
    specs: {
      display: { size: '6.7"', resolution: '1290x2796', type: 'LTPO Super Retina XDR OLED', refreshRate: '120Hz', protection: 'Ceramic Shield' },
      processor: { chipset: 'Apple A17 Pro (3 nm)', cpu: 'Hexa-core', gpu: 'Apple GPU (6-core)' },
      memory: { ram: '8GB', storage: '256GB/512GB/1TB', cardSlot: 'No' },
      camera: { main: '48MP+12MP+12MP', mainSensor: '48MP Main', aperture: 'f/1.78', ois: true, eis: false, zoom: '5x Optical', features: 'Night mode, Deep Fusion, ProRAW', video: '4K@60fps, ProRes', selfie: '12MP', selfieSensor: '12MP TrueDepth' },
      battery: { capacity: '4441mAh', charging: '27W wired, 15W MagSafe', wireless: true },
      connectivity: { network: '5G', wifi: 'Wi-Fi 6E', bluetooth: '5.3', nfc: true, usb: 'USB-C' },
      body: { dimensions: '159.9 x 76.7 x 8.3 mm', weight: '221g', build: 'Titanium frame, Glass back', sim: 'Dual eSIM', sarValue: '1.07 W/kg' },
      features: { fingerprint: 'No', faceUnlock: true, sensors: 'Face ID, LiDAR, Barometer, Gyro', colors: ['Natural Titanium', 'Blue Titanium', 'White Titanium', 'Black Titanium'], boxContents: 'USB-C cable' },
      os: { name: 'iOS', version: '17' }
    },
    ratings: { overall: 9.2, performance: 9.8, camera: 9.5, battery: 8.5, display: 9.7, value: 7.5 },
    review: { pros: ['Best performance', 'Excellent camera', 'Premium build'], cons: ['Expensive', 'No charger in box'], summary: 'The ultimate flagship with A17 Pro chip and titanium design' },
    benchmarks: { antutu: 1640000, geekbenchSingle: 2920, geekbenchMulti: 7250 },
    gaming: { pubgFps: '60 FPS Max', codMobileFps: '60 FPS Max', genshinFps: '60 FPS High' }
  },
  {
    brandName: 'Samsung',
    model: 'Galaxy S24 Ultra',
    slug: 'samsung-galaxy-s24-ultra',
    price: 419999,
    ptaApproved: true,
    featured: true,
    trending: true,
    images: ['https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-s24-ultra-5g.jpg'],
    releaseDate: new Date('2024-01-31'),
    specs: {
      display: { size: '6.8"', resolution: '1440x3120', type: 'Dynamic AMOLED 2X', refreshRate: '120Hz', protection: 'Gorilla Armor' },
      processor: { chipset: 'Snapdragon 8 Gen 3 (4 nm)', cpu: 'Octa-core', gpu: 'Adreno 750' },
      memory: { ram: '12GB', storage: '256GB/512GB/1TB', cardSlot: 'No' },
      camera: { main: '200MP+50MP+12MP+10MP', mainSensor: '200MP ISOCELL HP2', aperture: 'f/1.7', ois: true, zoom: '10x Optical', features: 'AI Zoom, Expert RAW', video: '8K@30fps', selfie: '12MP' },
      battery: { capacity: '5000mAh', charging: '45W wired, 15W wireless', wireless: true },
      connectivity: { network: '5G', wifi: 'Wi-Fi 7', bluetooth: '5.3', nfc: true, usb: 'USB-C 3.2' },
      body: { dimensions: '162.3 x 79 x 8.6 mm', weight: '232g', build: 'Titanium frame, Gorilla Armor', sim: 'Dual SIM', sarValue: '1.19 W/kg' },
      features: { fingerprint: 'Ultrasonic under display', faceUnlock: true, sensors: 'S Pen, UWB, Barometer', colors: ['Titanium Gray', 'Titanium Black', 'Titanium Violet', 'Titanium Yellow'] },
      os: { name: 'Android', version: '14 (One UI 6.1)' }
    },
    ratings: { overall: 9.0, performance: 9.5, camera: 9.7, battery: 9.0, display: 9.8, value: 8.0 },
    review: { pros: ['Best camera phone', 'S Pen included', 'Excellent display'], cons: ['Heavy', 'Expensive'], summary: 'The best Android flagship with 200MP camera and S Pen' },
    benchmarks: { antutu: 1850000, geekbenchSingle: 2250, geekbenchMulti: 7000 },
    gaming: { pubgFps: '60 FPS Ultra', codMobileFps: '60 FPS Max', genshinFps: '60 FPS High' }
  },
  {
    brandName: 'OnePlus',
    model: 'OnePlus 12',
    slug: 'oneplus-12',
    price: 249999,
    ptaApproved: true,
    featured: true,
    trending: true,
    images: ['https://fdn2.gsmarena.com/vv/bigpic/oneplus-12.jpg'],
    releaseDate: new Date('2024-01-23'),
    specs: {
      display: { size: '6.82"', resolution: '1440x3168', type: 'LTPO AMOLED', refreshRate: '120Hz', protection: 'Gorilla Glass Victus 2' },
      processor: { chipset: 'Snapdragon 8 Gen 3 (4 nm)', cpu: 'Octa-core', gpu: 'Adreno 750' },
      memory: { ram: '12GB/16GB', storage: '256GB/512GB', cardSlot: 'No' },
      camera: { main: '50MP+64MP+48MP', mainSensor: '50MP Sony LYT-808', aperture: 'f/1.6', ois: true, zoom: '3x Optical', features: 'Hasselblad tuning', video: '8K@24fps', selfie: '32MP' },
      battery: { capacity: '5400mAh', charging: '100W wired, 50W wireless', wireless: true },
      connectivity: { network: '5G', wifi: 'Wi-Fi 7', bluetooth: '5.4', nfc: true, usb: 'USB-C 3.2' },
      body: { dimensions: '164.3 x 75.8 x 9.2 mm', weight: '220g', build: 'Glass front/back, Aluminum frame', sim: 'Dual SIM' },
      features: { fingerprint: 'Optical under display', faceUnlock: true, sensors: 'Infrared, Gyro, Compass', colors: ['Flowy Emerald', 'Silky Black'] },
      os: { name: 'Android', version: '14 (OxygenOS 14)' }
    },
    ratings: { overall: 9.0, performance: 9.6, camera: 8.8, battery: 9.5, display: 9.5, value: 9.0 },
    review: { pros: ['Super fast charging', 'Excellent performance', 'Great value'], cons: ['No IP rating', 'Average camera zoom'], summary: 'Flagship killer with 100W charging and Snapdragon 8 Gen 3' },
    benchmarks: { antutu: 1870000, geekbenchSingle: 2280, geekbenchMulti: 7100 },
    gaming: { pubgFps: '60 FPS Ultra', codMobileFps: '60 FPS Max', genshinFps: '60 FPS High' },
    batteryTests: { videoPlayback: '18 hours', gaming: '8 hours', browsing: '14 hours' }
  },
  {
    brandName: 'Google',
    model: 'Pixel 8 Pro',
    slug: 'google-pixel-8-pro',
    price: 289999,
    ptaApproved: false,
    featured: true,
    images: ['https://fdn2.gsmarena.com/vv/bigpic/google-pixel-8-pro.jpg'],
    releaseDate: new Date('2023-10-12'),
    specs: {
      display: { size: '6.7"', resolution: '1344x2992', type: 'LTPO OLED', refreshRate: '120Hz', protection: 'Gorilla Glass Victus 2' },
      processor: { chipset: 'Google Tensor G3 (4 nm)', cpu: 'Octa-core', gpu: 'Mali-G715 MC10' },
      memory: { ram: '12GB', storage: '128GB/256GB/512GB', cardSlot: 'No' },
      camera: { main: '50MP+48MP+48MP', mainSensor: '50MP Samsung GN2', aperture: 'f/1.68', ois: true, zoom: '5x Optical', features: 'Magic Eraser, Best Take, Night Sight', video: '4K@60fps', selfie: '10.5MP' },
      battery: { capacity: '5050mAh', charging: '30W wired, 23W wireless', wireless: true },
      connectivity: { network: '5G', wifi: 'Wi-Fi 7', bluetooth: '5.3', nfc: true, usb: 'USB-C 3.2' },
      body: { dimensions: '162.6 x 76.5 x 8.8 mm', weight: '213g', build: 'Glass back, Aluminum frame', sim: 'Dual eSIM' },
      features: { fingerprint: 'Ultrasonic under display', faceUnlock: true, sensors: 'Temperature sensor, Barometer', colors: ['Obsidian', 'Porcelain', 'Bay'] },
      os: { name: 'Android', version: '14' }
    },
    ratings: { overall: 8.8, performance: 8.5, camera: 9.8, battery: 8.5, display: 9.5, value: 8.5 },
    review: { pros: ['Best camera processing', 'Clean Android', '7 years updates'], cons: ['Expensive', 'Average battery'], summary: 'Photography king with Google AI and clean Android experience' },
    benchmarks: { antutu: 1150000, geekbenchSingle: 1760, geekbenchMulti: 4442 },
    gaming: { pubgFps: '60 FPS High', codMobileFps: '60 FPS High', genshinFps: '45 FPS Medium' }
  },
  {
    brandName: 'Xiaomi',
    model: 'Xiaomi 14 Pro',
    slug: 'xiaomi-14-pro',
    price: 199999,
    ptaApproved: true,
    trending: true,
    images: ['https://fdn2.gsmarena.com/vv/bigpic/xiaomi-14-pro.jpg'],
    releaseDate: new Date('2023-10-26'),
    specs: {
      display: { size: '6.73"', resolution: '1440x3200', type: 'LTPO AMOLED', refreshRate: '120Hz', protection: 'Gorilla Glass Victus' },
      processor: { chipset: 'Snapdragon 8 Gen 3 (4 nm)', cpu: 'Octa-core', gpu: 'Adreno 750' },
      memory: { ram: '12GB/16GB', storage: '256GB/512GB/1TB', cardSlot: 'No' },
      camera: { main: '50MP+50MP+50MP', mainSensor: '50MP Sony IMX989', aperture: 'f/1.42', ois: true, zoom: '3.2x Optical', features: 'Leica optics', video: '8K@24fps', selfie: '32MP' },
      battery: { capacity: '4880mAh', charging: '120W wired, 50W wireless', wireless: true },
      connectivity: { network: '5G', wifi: 'Wi-Fi 7', bluetooth: '5.4', nfc: true, usb: 'USB-C 3.2' },
      body: { dimensions: '161.4 x 74.6 x 8.5 mm', weight: '223g', build: 'Glass front/back', sim: 'Dual SIM' },
      features: { fingerprint: 'Optical under display', faceUnlock: true, sensors: 'Infrared, NFC', colors: ['Black', 'White', 'Green'] },
      os: { name: 'Android', version: '14 (HyperOS)' }
    },
    ratings: { overall: 8.9, performance: 9.5, camera: 9.2, battery: 9.3, display: 9.4, value: 9.2 },
    review: { pros: ['Ultra fast charging', 'Leica camera', 'Great value'], cons: ['No IP rating', 'HyperOS bugs'], summary: 'Best value flagship with 120W charging and Leica cameras' },
    benchmarks: { antutu: 1820000, geekbenchSingle: 2240, geekbenchMulti: 6890 },
    gaming: { pubgFps: '60 FPS Ultra', codMobileFps: '60 FPS Max', genshinFps: '60 FPS High' },
    batteryTests: { videoPlayback: '16 hours', gaming: '7.5 hours', browsing: '13 hours' }
  }
];

async function seedData() {
  try {
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGO_URL);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    console.log('🗑️  Clearing existing data...');
    await Brand.deleteMany({});
    await Phone.deleteMany({});
    console.log('✅ Cleared existing data');

    // Insert brands
    console.log('📦 Inserting brands...');
    const brands = await Brand.insertMany(brandsData);
    console.log(`✅ Inserted ${brands.length} brands`);

    // Map brand names to IDs
    const brandMap = {};
    brands.forEach(brand => {
      brandMap[brand.name] = brand._id;
    });

    // Add brandId to phones
    const phonesWithBrandId = phonesData.map(phone => ({
      ...phone,
      brandId: brandMap[phone.brandName]
    }));

    // Insert phones
    console.log('📱 Inserting phones...');
    const phones = await Phone.insertMany(phonesWithBrandId);
    console.log(`✅ Inserted ${phones.length} phones`);

    console.log('\n🎉 Database seeded successfully!');
    console.log('\n📊 Summary:');
    console.log(`   Brands: ${brands.length}`);
    console.log(`   Phones: ${phones.length}`);
    console.log('\n💡 Next steps:');
    console.log('   1. Visit http://localhost:3000');
    console.log('   2. Check homepage sections');
    console.log('   3. Test search and filters');

  } catch (error) {
    console.error('❌ Error seeding data:', error);
  } finally {
    await mongoose.connection.close();
    console.log('👋 Disconnected from MongoDB');
  }
}

// Run seeding
seedData();
