// PhoneDock Professional Phone Import System
// Usage: node scripts/importPhones.js <json-file-path>

import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';
import Brand from '../models/Brand.js';
import Phone from '../models/Phone.js';

const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/phonedock';

// Utility: Generate slug from model name
function generateSlug(brand, model) {
  return `${brand}-${model}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// Utility: Validate phone data
function validatePhone(phone, index) {
  const errors = [];
  
  if (!phone.brand) errors.push(`Phone ${index}: Missing brand`);
  if (!phone.model) errors.push(`Phone ${index}: Missing model name`);
  if (!phone.price || phone.price <= 0) errors.push(`Phone ${index}: Invalid price`);
  
  return errors;
}

// Utility: Auto-generate SEO data
function generateSEO(phone) {
  const seoTitle = `${phone.brand} ${phone.model} Price in Pakistan - Specs, Reviews | PhoneDock`;
  const seoDescription = `${phone.brand} ${phone.model} price in Pakistan. Complete specifications, camera details, battery life, performance reviews. ${phone.ptaApproved ? 'PTA Approved' : 'Import'} - Latest ${new Date().getFullYear()} model.`;
  
  const keywords = [
    `${phone.brand} ${phone.model}`,
    `${phone.brand} ${phone.model} price in Pakistan`,
    `${phone.brand} ${phone.model} specs`,
    `${phone.brand} ${phone.model} review`,
    phone.ptaApproved ? 'PTA approved' : 'import',
    phone.specs?.processor?.chipset || 'smartphone',
    phone.specs?.camera?.main || 'camera phone'
  ];
  
  const faqs = [
    {
      question: `What is the price of ${phone.brand} ${phone.model} in Pakistan?`,
      answer: `The ${phone.brand} ${phone.model} is priced at PKR ${phone.price.toLocaleString()} in Pakistan.`
    },
    {
      question: `Is ${phone.brand} ${phone.model} PTA approved?`,
      answer: phone.ptaApproved 
        ? `Yes, ${phone.brand} ${phone.model} is PTA approved and can be used with all Pakistani networks.`
        : `No, ${phone.brand} ${phone.model} is not officially PTA approved yet. Import models are available.`
    }
  ];
  
  if (phone.specs?.processor?.chipset) {
    faqs.push({
      question: `What processor does ${phone.brand} ${phone.model} have?`,
      answer: `${phone.brand} ${phone.model} is powered by ${phone.specs.processor.chipset} processor.`
    });
  }
  
  return { title: seoTitle, description: seoDescription, keywords, faqs };
}

// Main Import Function
async function importPhones(jsonFilePath) {
  try {
    console.log('🚀 PhoneDock Professional Phone Import System\n');
    
    // Step 1: Read JSON file
    console.log('📂 Reading JSON file...');
    if (!fs.existsSync(jsonFilePath)) {
      throw new Error(`File not found: ${jsonFilePath}`);
    }
    
    const rawData = fs.readFileSync(jsonFilePath, 'utf-8');
    let phonesData;
    
    try {
      phonesData = JSON.parse(rawData);
    } catch (e) {
      throw new Error('Invalid JSON format');
    }
    
    // Handle both array and object with phones array
    if (!Array.isArray(phonesData)) {
      if (phonesData.phones && Array.isArray(phonesData.phones)) {
        phonesData = phonesData.phones;
      } else {
        throw new Error('JSON must contain an array of phones or an object with "phones" array');
      }
    }
    
    console.log(`✅ Found ${phonesData.length} phones in file\n`);
    
    // Step 2: Connect to MongoDB
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGO_URL);
    console.log('✅ Connected\n');
    
    // Step 3: Load existing brands
    console.log('📦 Loading brands...');
    const brands = await Brand.find({});
    const brandMap = {};
    brands.forEach(b => {
      brandMap[b.name.toLowerCase()] = b._id;
    });
    console.log(`✅ Loaded ${brands.length} brands\n`);
    
    // Step 4: Validate all phones
    console.log('🔍 Validating phone data...');
    const validationErrors = [];
    phonesData.forEach((phone, index) => {
      const errors = validatePhone(phone, index + 1);
      validationErrors.push(...errors);
    });
    
    if (validationErrors.length > 0) {
      console.log('❌ Validation errors found:\n');
      validationErrors.forEach(err => console.log(`   - ${err}`));
      throw new Error('Validation failed');
    }
    console.log('✅ All phones validated\n');
    
    // Step 5: Process and import
    console.log('📱 Processing phones...\n');
    
    const results = {
      total: phonesData.length,
      imported: 0,
      skipped: 0,
      errors: []
    };
    
    for (let i = 0; i < phonesData.length; i++) {
      const phoneData = phonesData[i];
      const phoneNum = i + 1;
      
      try {
        // Generate slug if not provided
        if (!phoneData.slug) {
          phoneData.slug = generateSlug(phoneData.brand, phoneData.model);
        }
        
        // Check for duplicate
        const existing = await Phone.findOne({ slug: phoneData.slug });
        if (existing) {
          console.log(`   [${phoneNum}/${results.total}] ⏭️  Skipped: ${phoneData.brand} ${phoneData.model} (already exists)`);
          results.skipped++;
          continue;
        }
        
        // Get brand ID
        const brandId = brandMap[phoneData.brand.toLowerCase()];
        if (!brandId) {
          throw new Error(`Brand not found: ${phoneData.brand}`);
        }
        
        // Auto-generate SEO if not provided
        if (!phoneData.seo) {
          phoneData.seo = generateSEO(phoneData);
        }
        
        // Add brand ID and name
        phoneData.brandId = brandId;
        phoneData.brandName = phoneData.brand;
        
        // Create phone
        await Phone.create(phoneData);
        
        console.log(`   [${phoneNum}/${results.total}] ✅ Imported: ${phoneData.brand} ${phoneData.model}`);
        results.imported++;
        
      } catch (error) {
        console.log(`   [${phoneNum}/${results.total}] ❌ Error: ${phoneData.brand} ${phoneData.model} - ${error.message}`);
        results.errors.push({
          phone: `${phoneData.brand} ${phoneData.model}`,
          error: error.message
        });
      }
    }
    
    // Step 6: Summary
    console.log('\n' + '='.repeat(60));
    console.log('📊 IMPORT SUMMARY');
    console.log('='.repeat(60));
    console.log(`Total phones in file:  ${results.total}`);
    console.log(`Successfully imported:  ${results.imported} ✅`);
    console.log(`Skipped (duplicates):  ${results.skipped} ⏭️`);
    console.log(`Errors:                ${results.errors.length} ❌`);
    console.log('='.repeat(60));
    
    if (results.errors.length > 0) {
      console.log('\n⚠️  ERRORS DETAIL:');
      results.errors.forEach((err, i) => {
        console.log(`   ${i + 1}. ${err.phone}: ${err.error}`);
      });
    }
    
    console.log('\n✨ Import process completed!\n');
    
  } catch (error) {
    console.error('\n❌ FATAL ERROR:', error.message);
    process.exit(1);
  } finally {
    await mongoose.connection.close();
    console.log('👋 Disconnected from MongoDB\n');
  }
}

// CLI execution
const args = process.argv.slice(2);
if (args.length === 0) {
  console.log('Usage: node scripts/importPhones.js <json-file-path>');
  console.log('\nExample:');
  console.log('  node scripts/importPhones.js data/flagship-phones.json');
  process.exit(1);
}

const jsonFile = args[0];
importPhones(jsonFile);
