#!/bin/bash
# PhoneDock Database Restore Script

if [ -z "$1" ]; then
    echo "Usage: ./restore.sh <backup_file.tar.gz>"
    echo "Available backups:"
    ls -lh /app/backups/*.tar.gz 2>/dev/null || echo "No backups found"
    exit 1
fi

BACKUP_FILE=$1
TEMP_DIR="/tmp/phonedock_restore"

if [ ! -f "$BACKUP_FILE" ]; then
    echo "Error: Backup file not found: $BACKUP_FILE"
    exit 1
fi

echo "Starting PhoneDock database restore..."
echo "Backup file: $BACKUP_FILE"

# Extract backup
mkdir -p $TEMP_DIR
tar -xzf $BACKUP_FILE -C $TEMP_DIR

# Restore collections
echo "Restoring brands..."
mongoimport --db=phonedock --collection=brands --file=$TEMP_DIR/*_brands.json --jsonArray --drop

echo "Restoring phones..."
mongoimport --db=phonedock --collection=phones --file=$TEMP_DIR/*_phones.json --jsonArray --drop

echo "Restoring admins..."
mongoimport --db=phonedock --collection=admins --file=$TEMP_DIR/*_admins.json --jsonArray --drop

echo "Restoring news..."
mongoimport --db=phonedock --collection=news --file=$TEMP_DIR/*_news.json --jsonArray --drop

# Cleanup
rm -rf $TEMP_DIR

echo "✅ Restore completed successfully!"
