# PhoneDock - Pakistan's #1 Smartphone Database

A professional, GSMArena-inspired smartphone database platform specifically designed for Pakistan market with complete specifications, latest prices, PTA status, expert reviews, and honest ratings.

![Version](https://img.shields.io/badge/version-1.0-blue)
![Next.js](https://img.shields.io/badge/Next.js-15-black)
![MongoDB](https://img.shields.io/badge/MongoDB-Latest-green)
![Status](https://img.shields.io/badge/status-MVP-orange)

## 🌟 Live Demo

**Website:** https://phone-database-test.preview.emergentagent.com  
**Admin Panel:** https://phone-database-test.preview.emergentagent.com/admin/login

## 📱 Features

### For Visitors
- 🔍 **Smart Search** - Search phones by name, brand, or chipset
- 📊 **Complete Specifications** - Detailed specs for every phone
- ⚖️ **Compare Phones** - Side-by-side comparison tool
- 💰 **Pakistan Prices** - Latest prices in PKR
- ✅ **PTA Status** - Official PTA approval status
- ⭐ **Expert Ratings** - Performance, camera, battery, display scores
- 📰 **Latest News** - Stay updated with tech news
- 🏷️ **Price Categories** - Browse by budget (Under 20K to 100K+)

### For Admins
- 📱 **Phone Management** - Add, edit, delete phones with complete specs
- 🏢 **Brand Management** - Manage smartphone brands
- 📝 **News Management** - Publish articles and updates
- 📊 **Dashboard** - Statistics and quick actions
- 🔒 **Secure Login** - JWT-based authentication

## 🛠️ Tech Stack

- **Frontend:** Next.js 15 (App Router), React 18
- **Backend:** Next.js API Routes
- **Database:** MongoDB with Mongoose ODM
- **Authentication:** JWT + bcryptjs
- **UI:** Tailwind CSS + shadcn/ui
- **Icons:** Lucide React
- **Hosting:** Vercel-ready

## 📦 Installation

### Prerequisites
- Node.js 18+
- MongoDB (local or cloud)
- yarn

### Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd app
```

2. **Install dependencies**
```bash
yarn install
```

3. **Configure environment**
Create `.env` file:
```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=phonedock
JWT_SECRET=your-secret-key-change-in-production
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```

4. **Seed sample data** (optional)
```bash
node scripts/seed.js
```

5. **Run development server**
```bash
yarn dev
```

Website will be available at: http://localhost:3000

## 📚 Documentation

- **[FEATURES.md](./FEATURES.md)** - Complete features list with status
- **[DATABASE.md](./DATABASE.md)** - Database structure and schemas
- **[EXPORT_GUIDE.md](./EXPORT_GUIDE.md)** - How to export and audit

## 🗂️ Project Structure

```
/app/
├── app/                    # Next.js app directory
│   ├── page.js            # Homepage
│   ├── layout.js          # Root layout with SEO
│   ├── api/               # API routes
│   ├── admin/             # Admin panel
│   ├── phone/             # Phone detail pages
│   ├── brands/            # Brand pages
│   ├── compare/           # Compare page
│   ├── search/            # Search page
│   └── news/              # News pages
├── components/            # React components
│   └── ui/               # shadcn UI components
├── lib/                  # Utilities
│   ├── db.js            # MongoDB connection
│   └── auth.js          # Authentication
├── models/              # Mongoose models
│   ├── Admin.js
│   ├── Brand.js
│   ├── Phone.js
│   ├── News.js
│   ├── Video.js
│   ├── Sponsor.js
│   └── Benchmark.js
├── scripts/            # Utility scripts
│   ├── backup.sh      # Database backup
│   ├── restore.sh     # Database restore
│   └── seed.js        # Sample data
└── public/            # Static files
```

## 🚀 Usage

### Admin Panel

1. **First Time Setup**
   - Go to `/admin/login`
   - Click "Need to create an admin account?"
   - Enter credentials and create account

2. **Add Brands**
   - Dashboard → "Manage Brands"
   - Click "Add Brand"
   - Fill details (Name, Slug, Country, Description)
   - Save

3. **Add Phones**
   - Dashboard → "Manage Phones"
   - Click "Add Phone"
   - Select brand
   - Fill complete details:
     - Basic info (model, slug, price, images)
     - Specifications (display, processor, camera, battery, etc.)
     - Ratings (0-10 scale)
     - Review (pros, cons, summary)
   - Save

## 💾 Database Backup

### Create Backup
```bash
cd /app && bash scripts/backup.sh
```

Backup saved to: `/app/backups/phonedock_backup_YYYYMMDD_HHMMSS.tar.gz`

### Restore Backup
```bash
bash scripts/restore.sh /app/backups/backup_file.tar.gz
```

## 🔐 Security

- ✅ JWT authentication
- ✅ Password hashing (bcryptjs)
- ✅ Protected admin routes
- ✅ Input validation
- ✅ XSS protection
- ✅ Environment variables
- ✅ Secure API endpoints

## 📈 SEO Features

- ✅ SEO-friendly URLs (slugs)
- ✅ Meta tags (title, description)
- ✅ Open Graph tags
- ✅ Twitter Cards
- ✅ Sitemap.xml
- ✅ Robots.txt
- ✅ Schema.org markup
- ✅ Fast page loads

## 🎨 Design

- **Theme:** Professional Blue/Indigo gradient
- **Layout:** Clean, modern, GSMArena-inspired
- **Responsive:** Mobile-first design
- **Icons:** Lucide React
- **Components:** shadcn/ui

## 📊 Current Status

**Version:** 1.0 (MVP)  
**Completion:** ~70%

### ✅ Completed
- Homepage with sections
- Phone detail pages
- Compare system
- Brand pages
- Search functionality
- Admin CRUD
- SEO optimization
- Database backup

### 🔄 In Progress
- Advanced filters
- YouTube integration
- Sponsor management
- Benchmark displays

### 📋 Planned
- Image upload (Cloudinary)
- PWA mobile app
- Activity logs
- Advanced analytics

## 🤝 Contributing

For audit and improvements, see [EXPORT_GUIDE.md](./EXPORT_GUIDE.md)

## 📄 License

Proprietary - All rights reserved

## 👨‍💻 Development

**Built with:** Next.js 15 + MongoDB  
**Developer:** PhoneDock Team  
**Last Updated:** 2025-07-12

## 📞 Support

For issues or questions:
- Check documentation files
- Review [FEATURES.md](./FEATURES.md)
- Review [DATABASE.md](./DATABASE.md)

---

**Made with ❤️ in Pakistan** 🇵🇰
