'use client'

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Smartphone, Search, ArrowLeft, Plus, X, ChevronDown, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function ComparePage() {
  const [allPhones, setAllPhones] = useState([]);
  const [selectedPhones, setSelectedPhones] = useState([null, null]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPhones();
  }, []);

  async function loadPhones() {
    try {
      const response = await fetch('/api/phones?limit=100');
      const data = await response.json();
      setAllPhones(data.phones || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading phones:', error);
      setLoading(false);
    }
  }

  const selectPhone = (index, phone) => {
    const newSelected = [...selectedPhones];
    newSelected[index] = phone;
    setSelectedPhones(newSelected);
    setShowDropdown(null);
    setSearchQuery('');
  };

  const removePhone = (index) => {
    const newSelected = [...selectedPhones];
    newSelected[index] = null;
    setSelectedPhones(newSelected);
  };

  const addCompareSlot = () => {
    if (selectedPhones.length < 4) {
      setSelectedPhones([...selectedPhones, null]);
    }
  };

  const filteredPhones = searchQuery
    ? allPhones.filter(phone => 
        phone.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
        phone.brandName.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allPhones;

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getComparison = (spec1, spec2) => {
    if (!spec1 || !spec2) return 'neutral';
    if (typeof spec1 === 'number' && typeof spec2 === 'number') {
      if (spec1 > spec2) return 'better';
      if (spec1 < spec2) return 'worse';
    }
    return 'neutral';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-cyan-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/" className="text-slate-600 hover:text-cyan-600 transition">Home</Link>
              <Link href="/phones" className="text-slate-600 hover:text-cyan-600 transition">Phones</Link>
              <Link href="/brands" className="text-slate-600 hover:text-cyan-600 transition">Brands</Link>
              <Link href="/compare" className="text-slate-800 font-semibold hover:text-cyan-600 transition">Compare</Link>
              <Link href="/news" className="text-slate-600 hover:text-cyan-600 transition">News</Link>
            </nav>

            <Link href="/">
              <Button variant="ghost" className="text-slate-600 hover:text-cyan-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Banner */}
      <section className="bg-gradient-to-r from-yellow-50 via-amber-50 to-yellow-50 border-b">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-slate-800 mb-4">Compare Phones</h1>
            <p className="text-lg text-slate-600">Compare specifications, features, and prices side by side</p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Phone Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {selectedPhones.map((phone, index) => (
            <div key={index} className="relative">
              {phone ? (
                <Card className="border-2 border-cyan-500">
                  <CardContent className="p-4">
                    <button
                      onClick={() => removePhone(index)}
                      className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 z-10"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="aspect-square bg-slate-50 rounded-lg mb-3 flex items-center justify-center">
                      {phone.images?.[0] ? (
                        <img src={phone.images[0]} alt={phone.model} className="w-full h-full object-contain" />
                      ) : (
                        <Smartphone className="w-16 h-16 text-slate-300" />
                      )}
                    </div>
                    <div className="text-xs text-slate-500 mb-1">{phone.brandName}</div>
                    <h3 className="font-bold text-slate-800 text-sm line-clamp-2 mb-2">{phone.model}</h3>
                    {phone.price > 0 && (
                      <div className="text-base font-bold text-cyan-600">{formatPrice(phone.price)}</div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-2 border-dashed border-slate-300 hover:border-cyan-500 transition cursor-pointer" onClick={() => setShowDropdown(index)}>
                  <CardContent className="p-8 text-center">
                    <Plus className="w-12 h-12 mx-auto mb-2 text-slate-400" />
                    <p className="text-sm text-slate-600 font-medium">Select Phone {index + 1}</p>
                  </CardContent>
                </Card>
              )}
              
              {/* Dropdown */}
              {showDropdown === index && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white border-2 border-cyan-500 rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
                  <div className="p-3 border-b sticky top-0 bg-white">
                    <Input
                      type="text"
                      placeholder="Search phones..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full"
                      autoFocus
                    />
                  </div>
                  <div className="p-2">
                    {filteredPhones.slice(0, 20).map((phone) => (
                      <button
                        key={phone._id}
                        onClick={() => selectPhone(index, phone)}
                        className="w-full text-left p-3 hover:bg-cyan-50 rounded-lg flex items-center gap-3 transition"
                      >
                        <div className="w-12 h-12 bg-slate-50 rounded flex items-center justify-center shrink-0">
                          {phone.images?.[0] ? (
                            <img src={phone.images[0]} alt={phone.model} className="w-full h-full object-contain" />
                          ) : (
                            <Smartphone className="w-6 h-6 text-slate-300" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="text-xs text-slate-500">{phone.brandName}</div>
                          <div className="font-semibold text-slate-800 text-sm">{phone.model}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                  <div className="p-3 border-t bg-slate-50">
                    <Button variant="ghost" size="sm" className="w-full" onClick={() => setShowDropdown(null)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {selectedPhones.length < 4 && (
          <div className="text-center mb-8">
            <Button onClick={addCompareSlot} variant="outline" className="border-cyan-600 text-cyan-600 hover:bg-cyan-50">
              <Plus className="w-4 h-4 mr-2" />
              Add Another Phone
            </Button>
          </div>
        )}

        {/* Comparison Table */}
        {selectedPhones.filter(p => p).length >= 2 && (
          <div className="bg-white rounded-lg border-2 border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white">
                    <th className="p-4 text-left font-semibold">Specification</th>
                    {selectedPhones.map((phone, i) => phone && (
                      <th key={i} className="p-4 text-center font-semibold min-w-[200px]">{phone.model}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <CompareRow label="Price" values={selectedPhones.map(p => p?.price ? formatPrice(p.price) : '-')} type="price" />
                  <CompareRow label="Display Size" values={selectedPhones.map(p => p?.specs?.display?.size || '-')} />
                  <CompareRow label="Display Type" values={selectedPhones.map(p => p?.specs?.display?.type || '-')} />
                  <CompareRow label="Refresh Rate" values={selectedPhones.map(p => p?.specs?.display?.refreshRate || '-')} />
                  <CompareRow label="Chipset" values={selectedPhones.map(p => p?.specs?.processor?.chipset || '-')} />
                  <CompareRow label="CPU" values={selectedPhones.map(p => p?.specs?.processor?.cpu || '-')} />
                  <CompareRow label="GPU" values={selectedPhones.map(p => p?.specs?.processor?.gpu || '-')} />
                  <CompareRow label="RAM" values={selectedPhones.map(p => p?.specs?.memory?.ram || '-')} />
                  <CompareRow label="Storage" values={selectedPhones.map(p => p?.specs?.memory?.storage || '-')} />
                  <CompareRow label="Main Camera" values={selectedPhones.map(p => p?.specs?.camera?.main || '-')} />
                  <CompareRow label="Selfie Camera" values={selectedPhones.map(p => p?.specs?.camera?.selfie || '-')} />
                  <CompareRow label="Battery" values={selectedPhones.map(p => p?.specs?.battery?.capacity || '-')} />
                  <CompareRow label="Charging" values={selectedPhones.map(p => p?.specs?.battery?.charging || '-')} />
                  <CompareRow label="Weight" values={selectedPhones.map(p => p?.specs?.body?.weight || '-')} />
                  <CompareRow label="OS" values={selectedPhones.map(p => p?.specs?.os?.name || '-')} />
                  <CompareRow label="PTA Approved" values={selectedPhones.map(p => p?.ptaApproved ? '✓ Yes' : '✗ No')} />
                  <CompareRow label="Overall Rating" values={selectedPhones.map(p => p?.ratings?.overall ? `${p.ratings.overall}/10` : '-')} type="rating" />
                </tbody>
              </table>
            </div>
          </div>
        )}

        {selectedPhones.filter(p => p).length < 2 && (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Smartphone className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">Select at least 2 phones</h3>
            <p className="text-slate-600">Click on the cards above to select phones for comparison</p>
          </div>
        )}
      </div>
    </div>
  );
}

function CompareRow({ label, values, type = 'text' }) {
  return (
    <tr className="border-b border-slate-100 hover:bg-slate-50">
      <td className="p-4 font-semibold text-slate-700 bg-slate-50">{label}</td>
      {values.map((value, i) => value !== null && (
        <td key={i} className="p-4 text-center text-slate-800">
          {value || '-'}
        </td>
      ))}
    </tr>
  );
}
