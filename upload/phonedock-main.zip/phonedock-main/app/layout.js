import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: {
    default: "PhoneDock - Pakistan's Best Smartphone Database | Complete Specs & Prices",
    template: "%s | PhoneDock - Pakistan's #1 Phone Database"
  },
  description: "Find complete smartphone specifications, latest prices in Pakistan, expert reviews, and honest ratings. Compare phones, browse by brand, and make informed buying decisions.",
  keywords: [
    "smartphones Pakistan",
    "mobile phones prices",
    "phone specifications",
    "PTA approved phones",
    "phone comparison",
    "phone reviews Pakistan",
    "Samsung phones Pakistan",
    "iPhone prices Pakistan",
    "Xiaomi phones",
    "phone database",
    "mobile specs"
  ],
  authors: [{ name: "PhoneDock Team" }],
  creator: "PhoneDock",
  publisher: "PhoneDock",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    type: 'website',
    locale: 'en_PK',
    url: '/',
    title: "PhoneDock - Pakistan's #1 Smartphone Database",
    description: "Complete specs, latest prices, and expert reviews of smartphones in Pakistan. Compare phones and make informed decisions.",
    siteName: 'PhoneDock',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'PhoneDock - Smartphone Database',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: "PhoneDock - Pakistan's #1 Smartphone Database",
    description: "Complete specs, latest prices, and expert reviews of smartphones in Pakistan.",
    images: ['/twitter-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/site.webmanifest',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="dns-prefetch" href="https://fonts.googleapis.com" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
