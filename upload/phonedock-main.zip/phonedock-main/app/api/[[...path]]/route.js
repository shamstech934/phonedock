import { NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Admin from '@/models/Admin';
import Brand from '@/models/Brand';
import Phone from '@/models/Phone';
import News from '@/models/News';
import Video from '@/models/Video';
import Sponsor from '@/models/Sponsor';
import Benchmark from '@/models/Benchmark';
import { hashPassword, comparePassword, generateToken, getAuthUser } from '@/lib/auth';

// Helper function to extract path from request
function getPath(request) {
  const url = new URL(request.url);
  const path = url.pathname.replace('/api', '') || '/';
  return path;
}

// Auth middleware
async function requireAuth(request) {
  const user = getAuthUser(request);
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  return user;
}

export async function GET(request) {
  try {
    await connectDB();
    const path = getPath(request);
    const { searchParams } = new URL(request.url);

    // Root endpoint
    if (path === '/' || path === '') {
      return NextResponse.json({ 
        message: 'PhoneDock API v1.0',
        status: 'running' 
      });
    }

    // Get all brands
    if (path === '/brands') {
      const brands = await Brand.find().sort({ name: 1 });
      return NextResponse.json({ brands });
    }

    // Get best camera phones
    if (path === '/phones/best-camera') {
      const phones = await Phone.find()
        .sort({ 'ratings.camera': -1 })
        .limit(6);
      return NextResponse.json({ phones });
    }

    // Get best gaming phones
    if (path === '/phones/best-gaming') {
      const phones = await Phone.find()
        .sort({ 'ratings.performance': -1 })
        .limit(6);
      return NextResponse.json({ phones });
    }

    // Get best battery phones
    if (path === '/phones/best-battery') {
      const phones = await Phone.find()
        .sort({ 'ratings.battery': -1 })
        .limit(6);
      return NextResponse.json({ phones });
    }

    // Get YouTube videos
    if (path === '/videos') {
      const videos = await Video.find({ published: true })
        .sort({ createdAt: -1 })
        .limit(parseInt(searchParams.get('limit')) || 10);
      return NextResponse.json({ videos });
    }

    // Get sponsors
    if (path === '/sponsors') {
      const position = searchParams.get('position');
      const filter = { active: true };
      if (position) filter.position = position;
      
      const sponsors = await Sponsor.find(filter)
        .sort({ priority: -1 })
        .limit(10);
      return NextResponse.json({ sponsors });
    }

    // Get single brand by slug
    if (path.startsWith('/brands/')) {
      const slug = path.split('/brands/')[1];
      const brand = await Brand.findOne({ slug });
      if (!brand) {
        return NextResponse.json({ error: 'Brand not found' }, { status: 404 });
      }
      const phones = await Phone.find({ brandId: brand._id }).sort({ createdAt: -1 });
      return NextResponse.json({ brand, phones });
    }

    // Get all phones with filters
    if (path === '/phones') {
      const page = parseInt(searchParams.get('page')) || 1;
      const limit = parseInt(searchParams.get('limit')) || 20;
      const skip = (page - 1) * limit;
      
      const filter = {};
      
      // Filter by brand
      if (searchParams.get('brand')) {
        filter.brandName = searchParams.get('brand');
      }
      
      // Filter by price range
      const minPrice = searchParams.get('minPrice');
      const maxPrice = searchParams.get('maxPrice');
      if (minPrice || maxPrice) {
        filter.price = {};
        if (minPrice) filter.price.$gte = parseInt(minPrice);
        if (maxPrice) filter.price.$lte = parseInt(maxPrice);
      }
      
      // Filter by status
      if (searchParams.get('trending') === 'true') {
        filter.trending = true;
      }
      if (searchParams.get('featured') === 'true') {
        filter.featured = true;
      }
      if (searchParams.get('upcoming') === 'true') {
        filter.upcoming = true;
      }
      
      // Sorting logic
      let sortBy = { createdAt: -1 }; // Default sort by newest
      const sortParam = searchParams.get('sortBy');
      if (sortParam === 'camera') {
        sortBy = { 'ratings.camera': -1, 'ratings.overall': -1 };
      } else if (sortParam === 'gaming') {
        sortBy = { 'ratings.performance': -1, 'ratings.overall': -1 };
      } else if (sortParam === 'battery') {
        sortBy = { 'ratings.battery': -1, 'ratings.overall': -1 };
      } else if (sortParam === 'price-low') {
        sortBy = { price: 1 };
      } else if (sortParam === 'price-high') {
        sortBy = { price: -1 };
      }
      
      const total = await Phone.countDocuments(filter);
      const phones = await Phone.find(filter)
        .sort(sortBy)
        .skip(skip)
        .limit(limit);
      
      return NextResponse.json({
        phones,
        pagination: {
          total,
          page,
          pages: Math.ceil(total / limit),
        },
      });
    }

    // Search phones
    if (path === '/phones/search') {
      const query = searchParams.get('q');
      if (!query) {
        return NextResponse.json({ phones: [] });
      }
      
      const phones = await Phone.find({
        $or: [
          { model: { $regex: query, $options: 'i' } },
          { brandName: { $regex: query, $options: 'i' } },
          { 'specs.processor.chipset': { $regex: query, $options: 'i' } },
        ],
      }).limit(20);
      
      return NextResponse.json({ phones });
    }

    // Get single phone by slug
    if (path.startsWith('/phones/')) {
      const slug = path.split('/phones/')[1];
      const phone = await Phone.findOne({ slug });
      if (!phone) {
        return NextResponse.json({ error: 'Phone not found' }, { status: 404 });
      }
      
      // Get related phones (same brand, similar price)
      const relatedPhones = await Phone.find({
        brandId: phone.brandId,
        _id: { $ne: phone._id },
        price: {
          $gte: phone.price * 0.7,
          $lte: phone.price * 1.3,
        },
      }).limit(4);
      
      return NextResponse.json({ phone, relatedPhones });
    }

    // Get news
    if (path === '/news') {
      const page = parseInt(searchParams.get('page')) || 1;
      const limit = parseInt(searchParams.get('limit')) || 10;
      const skip = (page - 1) * limit;
      
      const filter = { published: true };
      if (searchParams.get('category')) {
        filter.category = searchParams.get('category');
      }
      
      const total = await News.countDocuments(filter);
      const news = await News.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
      
      return NextResponse.json({
        news,
        pagination: {
          total,
          page,
          pages: Math.ceil(total / limit),
        },
      });
    }

    // Admin: Get all phones (with auth)
    if (path === '/admin/phones') {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const phones = await Phone.find().sort({ createdAt: -1 });
      return NextResponse.json({ phones });
    }

    // Admin: Get stats
    if (path === '/admin/stats') {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const totalPhones = await Phone.countDocuments();
      const totalBrands = await Brand.countDocuments();
      const totalNews = await News.countDocuments();
      const trendingPhones = await Phone.countDocuments({ trending: true });
      
      return NextResponse.json({
        totalPhones,
        totalBrands,
        totalNews,
        trendingPhones,
      });
    }

    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    await connectDB();
    const path = getPath(request);
    const body = await request.json();

    // Admin login
    if (path === '/auth/login') {
      const { username, password } = body;
      
      const admin = await Admin.findOne({ username });
      if (!admin || !comparePassword(password, admin.password)) {
        return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
      }
      
      const token = generateToken(admin._id);
      return NextResponse.json({
        token,
        admin: {
          id: admin._id,
          username: admin.username,
          email: admin.email,
          role: admin.role,
        },
      });
    }

    // Admin register (first time setup)
    if (path === '/auth/register') {
      const adminCount = await Admin.countDocuments();
      if (adminCount > 0) {
        return NextResponse.json({ error: 'Admin already exists' }, { status: 400 });
      }
      
      const { username, email, password } = body;
      
      const hashedPassword = hashPassword(password);
      const admin = await Admin.create({
        username,
        email,
        password: hashedPassword,
        role: 'superadmin',
      });
      
      const token = generateToken(admin._id);
      return NextResponse.json({
        token,
        admin: {
          id: admin._id,
          username: admin.username,
          email: admin.email,
          role: admin.role,
        },
      });
    }

    // Create brand (requires auth)
    if (path === '/admin/brands') {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const { name, slug, logo, country, description } = body;
      const brand = await Brand.create({ name, slug, logo, country, description });
      return NextResponse.json({ brand }, { status: 201 });
    }

    // Create phone (requires auth)
    if (path === '/admin/phones') {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const phone = await Phone.create(body);
      return NextResponse.json({ phone }, { status: 201 });
    }

    // Create news (requires auth)
    if (path === '/admin/news') {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const news = await News.create(body);
      return NextResponse.json({ news }, { status: 201 });
    }

    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    await connectDB();
    const path = getPath(request);
    const body = await request.json();

    // Update brand
    if (path.startsWith('/admin/brands/')) {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const id = path.split('/admin/brands/')[1];
      const brand = await Brand.findByIdAndUpdate(id, body, { new: true });
      if (!brand) {
        return NextResponse.json({ error: 'Brand not found' }, { status: 404 });
      }
      return NextResponse.json({ brand });
    }

    // Update phone
    if (path.startsWith('/admin/phones/')) {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const id = path.split('/admin/phones/')[1];
      const phone = await Phone.findByIdAndUpdate(id, body, { new: true });
      if (!phone) {
        return NextResponse.json({ error: 'Phone not found' }, { status: 404 });
      }
      return NextResponse.json({ phone });
    }

    // Update news
    if (path.startsWith('/admin/news/')) {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const id = path.split('/admin/news/')[1];
      const news = await News.findByIdAndUpdate(id, body, { new: true });
      if (!news) {
        return NextResponse.json({ error: 'News not found' }, { status: 404 });
      }
      return NextResponse.json({ news });
    }

    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    await connectDB();
    const path = getPath(request);

    // Delete brand
    if (path.startsWith('/admin/brands/')) {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const id = path.split('/admin/brands/')[1];
      const brand = await Brand.findByIdAndDelete(id);
      if (!brand) {
        return NextResponse.json({ error: 'Brand not found' }, { status: 404 });
      }
      return NextResponse.json({ message: 'Brand deleted' });
    }

    // Delete phone
    if (path.startsWith('/admin/phones/')) {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const id = path.split('/admin/phones/')[1];
      const phone = await Phone.findByIdAndDelete(id);
      if (!phone) {
        return NextResponse.json({ error: 'Phone not found' }, { status: 404 });
      }
      return NextResponse.json({ message: 'Phone deleted' });
    }

    // Delete news
    if (path.startsWith('/admin/news/')) {
      const authCheck = await requireAuth(request);
      if (authCheck instanceof NextResponse) return authCheck;
      
      const id = path.split('/admin/news/')[1];
      const news = await News.findByIdAndDelete(id);
      if (!news) {
        return NextResponse.json({ error: 'News not found' }, { status: 404 });
      }
      return NextResponse.json({ message: 'News deleted' });
    }

    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
