'use client'

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, Search, ArrowLeft, Star, X, Filter, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function SearchPage() {
  const searchParams = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [phones, setPhones] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter states
  const [filters, setFilters] = useState({
    ram: '',
    storage: '',
    chipset: '',
    minPrice: '',
    maxPrice: '',
    refreshRate: '',
    battery: '',
    camera: '',
    has5G: false,
  });

  useEffect(() => {
    const query = searchParams.get('q');
    if (query) {
      setSearchQuery(query);
      performSearch(query);
    }
  }, [searchParams]);

  async function performSearch(query) {
    if (!query.trim()) return;
    
    try {
      setLoading(true);
      setSearched(true);
      const response = await fetch(`/api/phones/search?q=${encodeURIComponent(query)}`);
      const data = await response.json();
      setPhones(data.phones || []);
      setLoading(false);
    } catch (error) {
      console.error('Error searching:', error);
      setLoading(false);
    }
  }

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.history.pushState({}, '', `/search?q=${encodeURIComponent(searchQuery)}`);
      performSearch(searchQuery);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-cyan-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            <Link href="/">
              <Button variant="ghost" className="text-slate-600 hover:text-cyan-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Search Section */}
      <section className="bg-gradient-to-r from-yellow-50 via-amber-50 to-yellow-50 border-b">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-slate-800 mb-6 text-center">Search Phones</h1>
            <form onSubmit={handleSearch} className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Search by phone name, brand, chipset, or features..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 h-14 text-base bg-white border-slate-300 shadow-sm"
                  autoFocus
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
              <Button type="submit" className="h-14 px-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white shadow-lg" disabled={loading}>
                {loading ? 'Searching...' : 'Search'}
              </Button>
            </form>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Results */}
        {searched && (
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-slate-800 mb-2">
              {loading ? 'Searching...' : `Found ${phones.length} results`}
            </h2>
            {searchQuery && (
              <p className="text-slate-600">Search results for: <span className="font-semibold">"{searchQuery}"</span></p>
            )}
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">
            <div className="text-slate-600">Searching phones...</div>
          </div>
        ) : !searched ? (
          <div className="text-center py-12">
            <Search className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">Search for phones</h3>
            <p className="text-slate-600">Enter phone name, brand, chipset, or features to search</p>
          </div>
        ) : phones.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Search className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">No results found</h3>
            <p className="text-slate-600 mb-4">Try searching with different keywords</p>
            <Button onClick={() => { setSearchQuery(''); setSearched(false); }} variant="outline">
              Clear Search
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {phones.map((phone) => (
              <Link key={phone._id} href={`/phone/${phone.slug}`}>
                <Card className="group hover:shadow-xl transition-all border-2 border-slate-200 hover:border-cyan-500 h-full">
                  <CardContent className="p-4">
                    <div className="aspect-square bg-slate-50 rounded-lg mb-3 flex items-center justify-center overflow-hidden">
                      {phone.images?.[0] ? (
                        <img 
                          src={phone.images[0]} 
                          alt={phone.model}
                          className="w-full h-full object-contain group-hover:scale-110 transition-transform"
                        />
                      ) : (
                        <Smartphone className="w-16 h-16 text-slate-300" />
                      )}
                    </div>
                    <div className="space-y-2">
                      <div className="text-xs text-slate-500">{phone.brandName}</div>
                      <h3 className="font-bold text-slate-800 line-clamp-2 text-sm group-hover:text-cyan-600 transition">
                        {phone.model}
                      </h3>
                      {phone.price > 0 && (
                        <div className="text-base font-bold text-cyan-600">
                          {formatPrice(phone.price)}
                        </div>
                      )}
                      <div className="flex flex-wrap gap-1">
                        {phone.trending && <Badge className="bg-red-500 text-white text-xs">Hot</Badge>}
                        {phone.ptaApproved && <Badge variant="outline" className="text-green-600 border-green-600 text-xs">PTA</Badge>}
                      </div>
                      {phone.ratings?.overall > 0 && (
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span className="font-semibold text-slate-700 text-sm">{phone.ratings.overall.toFixed(1)}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
