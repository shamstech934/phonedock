'use client'

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, Star, CheckCircle, ArrowLeft, Share2, Cpu, Camera, Battery, Monitor } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function PhoneDetailPage() {
  const params = useParams();
  const [phone, setPhone] = useState(null);
  const [relatedPhones, setRelatedPhones] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (params.slug) {
      loadPhone(params.slug);
    }
  }, [params.slug]);

  async function loadPhone(slug) {
    try {
      const response = await fetch(`/api/phones/${slug}`);
      const data = await response.json();
      
      if (data.error) {
        setLoading(false);
        return;
      }
      
      setPhone(data.phone);
      setRelatedPhones(data.relatedPhones || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading phone:', error);
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-xl text-slate-600">Loading...</div>
      </div>
    );
  }

  if (!phone) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Phone not found</h2>
          <Link href="/">
            <Button className="bg-cyan-600 hover:bg-cyan-700">Go to Homepage</Button>
          </Link>
        </div>
      </div>
    );
  }

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  // JSON-LD Schema for SEO
  const productSchema = {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": `${phone.brandName} ${phone.model}`,
    "image": phone.images || [],
    "description": phone.review?.summary || `${phone.brandName} ${phone.model} - Complete specifications, price in Pakistan, and expert review.`,
    "brand": {
      "@type": "Brand",
      "name": phone.brandName
    },
    "offers": {
      "@type": "Offer",
      "url": `${process.env.NEXT_PUBLIC_BASE_URL || 'https://phonedock.com'}/phone/${phone.slug}`,
      "priceCurrency": "PKR",
      "price": phone.price,
      "availability": phone.ptaApproved ? "https://schema.org/InStock" : "https://schema.org/PreOrder"
    },
    ...(phone.ratings?.overall > 0 && {
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": phone.ratings.overall,
        "bestRating": "10",
        "ratingCount": "1"
      }
    })
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* JSON-LD Schema */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-blue-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            <Link href="/">
              <Button variant="ghost" className="text-slate-600 hover:text-blue-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="text-sm text-slate-500 mb-4">
          <Link href="/" className="hover:text-blue-600">Home</Link>
          {' / '}
          <Link href="/phones" className="hover:text-blue-600">Phones</Link>
          {' / '}
          <span className="text-slate-800">{phone.model}</span>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Left Column - Image & Quick Specs */}
          <div>
            <Card className="border-slate-200 mb-4">
              <CardContent className="p-6">
                <div className="bg-slate-50 rounded-lg p-8 flex items-center justify-center mb-4">
                  {phone.images?.[0] ? (
                    <img 
                      src={phone.images[0]} 
                      alt={phone.model}
                      className="max-h-80 object-contain"
                    />
                  ) : (
                    <Smartphone className="w-48 h-48 text-slate-300" />
                  )}
                </div>
                
                {/* Image Gallery */}
                {phone.images?.length > 1 && (
                  <div className="grid grid-cols-4 gap-2">
                    {phone.images.slice(0, 4).map((img, i) => (
                      <div key={i} className="aspect-square bg-slate-50 rounded border border-slate-200 p-2">
                        <img src={img} alt={`${phone.model} ${i+1}`} className="w-full h-full object-contain" />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Specs */}
            <Card className="border-slate-200">
              <CardContent className="p-4">
                <h3 className="font-semibold text-slate-800 mb-3">Key Specs</h3>
                <div className="space-y-3">
                  {phone.specs?.display?.size && (
                    <div className="flex items-center gap-3">
                      <Monitor className="w-5 h-5 text-cyan-600" />
                      <div>
                        <div className="text-xs text-slate-500">Display</div>
                        <div className="text-sm font-medium text-slate-800">{phone.specs.display.size}</div>
                      </div>
                    </div>
                  )}
                  {phone.specs?.processor?.chipset && (
                    <div className="flex items-center gap-3">
                      <Cpu className="w-5 h-5 text-cyan-600" />
                      <div>
                        <div className="text-xs text-slate-500">Chipset</div>
                        <div className="text-sm font-medium text-slate-800">{phone.specs.processor.chipset}</div>
                      </div>
                    </div>
                  )}
                  {phone.specs?.camera?.main && (
                    <div className="flex items-center gap-3">
                      <Camera className="w-5 h-5 text-cyan-600" />
                      <div>
                        <div className="text-xs text-slate-500">Camera</div>
                        <div className="text-sm font-medium text-slate-800">{phone.specs.camera.main}</div>
                      </div>
                    </div>
                  )}
                  {phone.specs?.battery?.capacity && (
                    <div className="flex items-center gap-3">
                      <Battery className="w-5 h-5 text-cyan-600" />
                      <div>
                        <div className="text-xs text-slate-500">Battery</div>
                        <div className="text-sm font-medium text-slate-800">{phone.specs.battery.capacity}</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Details */}
          <div className="lg:col-span-2">
            <div className="text-sm text-slate-500 mb-1">{phone.brandName}</div>
            <h1 className="text-4xl font-bold text-slate-800 mb-4">{phone.model}</h1>
            
            <div className="flex flex-wrap gap-2 mb-4">
              {phone.trending && (
                <Badge className="bg-cyan-100 text-cyan-700 hover:bg-cyan-200">
                  Trending
                </Badge>
              )}
              {phone.featured && <Badge className="bg-blue-100 text-blue-700">Featured</Badge>}
              {phone.ptaApproved && (
                <Badge variant="outline" className="text-green-600 border-green-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  PTA Approved
                </Badge>
              )}
            </div>

            {phone.price > 0 && (
              <div className="mb-6">
                <div className="text-sm text-slate-500 mb-1">Price in Pakistan</div>
                <div className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {formatPrice(phone.price)}
                </div>
              </div>
            )}

            {/* Ratings */}
            {phone.ratings?.overall > 0 && (
              <Card className="border-2 border-blue-500 bg-blue-50 mb-6">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-sm text-slate-600 mb-1">Overall Rating</div>
                      <div className="flex items-center gap-2 mb-4">
                        <Star className="w-10 h-10 fill-amber-400 text-amber-400" />
                        <span className="text-4xl font-bold text-slate-800">{phone.ratings.overall.toFixed(1)}</span>
                        <span className="text-slate-500">/10</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {phone.ratings.performance > 0 && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Performance</span>
                        <span className="font-semibold text-slate-800">{phone.ratings.performance}/10</span>
                      </div>
                    )}
                    {phone.ratings.camera > 0 && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Camera</span>
                        <span className="font-semibold text-slate-800">{phone.ratings.camera}/10</span>
                      </div>
                    )}
                    {phone.ratings.battery > 0 && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Battery</span>
                        <span className="font-semibold text-slate-800">{phone.ratings.battery}/10</span>
                      </div>
                    )}
                    {phone.ratings.display > 0 && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Display</span>
                        <span className="font-semibold text-slate-800">{phone.ratings.display}/10</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Tabs */}
            <Tabs defaultValue="specs" className="mb-8">
              <TabsList className="grid w-full grid-cols-5 bg-white border">
                <TabsTrigger value="specs" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Specs</TabsTrigger>
                <TabsTrigger value="benchmarks" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Benchmark</TabsTrigger>
                <TabsTrigger value="gaming" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Gaming</TabsTrigger>
                <TabsTrigger value="battery" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Battery</TabsTrigger>
                <TabsTrigger value="review" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">Review</TabsTrigger>
              </TabsList>
              
              <TabsContent value="specs" className="mt-4">
                <Card className="border-slate-200">
                  <CardContent className="p-6">
                    <SpecSection title="Display" specs={phone.specs?.display} />
                    <Separator className="my-4" />
                    <SpecSection title="Processor" specs={phone.specs?.processor} />
                    <Separator className="my-4" />
                    <SpecSection title="Memory" specs={phone.specs?.memory} />
                    <Separator className="my-4" />
                    <SpecSection title="Camera" specs={phone.specs?.camera} />
                    <Separator className="my-4" />
                    <SpecSection title="Battery" specs={phone.specs?.battery} />
                    <Separator className="my-4" />
                    <SpecSection title="Connectivity" specs={phone.specs?.connectivity} />
                    <Separator className="my-4" />
                    <SpecSection title="Body" specs={phone.specs?.body} />
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="review" className="mt-4">
                <Card className="border-slate-200">
                  <CardContent className="p-6">
                    {phone.review?.summary && (
                      <div className="mb-6">
                        <h3 className="font-semibold text-lg text-slate-800 mb-3">Summary</h3>
                        <p className="text-slate-600 leading-relaxed">{phone.review.summary}</p>
                      </div>
                    )}
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      {phone.review?.pros?.length > 0 && (
                        <div>
                          <h3 className="font-semibold text-lg text-green-600 mb-3 flex items-center gap-2">
                            <CheckCircle className="w-5 h-5" />
                            Pros
                          </h3>
                          <ul className="space-y-2">
                            {phone.review.pros.map((pro, i) => (
                              <li key={i} className="flex items-start gap-2 text-slate-700">
                                <span className="text-green-600 mt-0.5">✓</span>
                                <span>{pro}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {phone.review?.cons?.length > 0 && (
                        <div>
                          <h3 className="font-semibold text-lg text-red-600 mb-3">Cons</h3>
                          <ul className="space-y-2">
                            {phone.review.cons.map((con, i) => (
                              <li key={i} className="flex items-start gap-2 text-slate-700">
                                <span className="text-red-600 mt-0.5">✗</span>
                                <span>{con}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="benchmarks" className="mt-4">
                <Card className="border-slate-200">
                  <CardContent className="p-6">
                    {phone.benchmarks && (phone.benchmarks.antutu > 0 || phone.benchmarks.geekbenchSingle > 0) ? (
                      <div className="grid md:grid-cols-3 gap-6">
                        {phone.benchmarks?.antutu > 0 && (
                          <div className="text-center p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                            <div className="text-sm text-slate-600 mb-2">AnTuTu Score</div>
                            <div className="text-3xl font-bold text-blue-600">{phone.benchmarks.antutu.toLocaleString()}</div>
                            <div className="text-xs text-slate-500 mt-2">Overall Performance</div>
                          </div>
                        )}
                        {phone.benchmarks?.geekbenchSingle > 0 && (
                          <div className="text-center p-4 bg-purple-50 rounded-lg border-2 border-purple-200">
                            <div className="text-sm text-slate-600 mb-2">Geekbench Single</div>
                            <div className="text-3xl font-bold text-purple-600">{phone.benchmarks.geekbenchSingle.toLocaleString()}</div>
                            <div className="text-xs text-slate-500 mt-2">Single Core</div>
                          </div>
                        )}
                        {phone.benchmarks?.geekbenchMulti > 0 && (
                          <div className="text-center p-4 bg-indigo-50 rounded-lg border-2 border-indigo-200">
                            <div className="text-sm text-slate-600 mb-2">Geekbench Multi</div>
                            <div className="text-3xl font-bold text-indigo-600">{phone.benchmarks.geekbenchMulti.toLocaleString()}</div>
                            <div className="text-xs text-slate-500 mt-2">Multi Core</div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-slate-500">
                        <div className="text-4xl mb-2">📊</div>
                        <p>Benchmark data coming soon!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="gaming" className="mt-4">
                <Card className="border-slate-200">
                  <CardContent className="p-6">
                    {phone.gaming && (phone.gaming.pubgFps || phone.gaming.codMobileFps || phone.gaming.genshinFps) ? (
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg text-slate-800 mb-4">Gaming Performance (FPS)</h3>
                        <div className="grid md:grid-cols-3 gap-4">
                          {phone.gaming.pubgFps && (
                            <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200">
                              <div className="text-sm font-semibold text-slate-700 mb-2">PUBG Mobile</div>
                              <div className="text-2xl font-bold text-green-600">{phone.gaming.pubgFps}</div>
                              <div className="text-xs text-slate-500 mt-1">HD Graphics</div>
                            </div>
                          )}
                          {phone.gaming.codMobileFps && (
                            <div className="p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                              <div className="text-sm font-semibold text-slate-700 mb-2">COD Mobile</div>
                              <div className="text-2xl font-bold text-blue-600">{phone.gaming.codMobileFps}</div>
                              <div className="text-xs text-slate-500 mt-1">High Settings</div>
                            </div>
                          )}
                          {phone.gaming.genshinFps && (
                            <div className="p-4 bg-purple-50 rounded-lg border-2 border-purple-200">
                              <div className="text-sm font-semibold text-slate-700 mb-2">Genshin Impact</div>
                              <div className="text-2xl font-bold text-purple-600">{phone.gaming.genshinFps}</div>
                              <div className="text-xs text-slate-500 mt-1">Medium Settings</div>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-slate-500">
                        <div className="text-4xl mb-2">🎮</div>
                        <p>Gaming performance data coming soon!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="battery" className="mt-4">
                <Card className="border-slate-200">
                  <CardContent className="p-6">
                    {phone.batteryTests && (phone.batteryTests.videoPlayback || phone.batteryTests.gaming || phone.batteryTests.browsing) ? (
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg text-slate-800 mb-4">Battery Life Tests</h3>
                        <div className="grid md:grid-cols-3 gap-4">
                          {phone.batteryTests.videoPlayback && (
                            <div className="p-4 bg-amber-50 rounded-lg border-2 border-amber-200">
                              <div className="text-sm font-semibold text-slate-700 mb-2">📺 Video Playback</div>
                              <div className="text-2xl font-bold text-amber-600">{phone.batteryTests.videoPlayback}</div>
                              <div className="text-xs text-slate-500 mt-1">Continuous playback</div>
                            </div>
                          )}
                          {phone.batteryTests.gaming && (
                            <div className="p-4 bg-red-50 rounded-lg border-2 border-red-200">
                              <div className="text-sm font-semibold text-slate-700 mb-2">🎮 Gaming</div>
                              <div className="text-2xl font-bold text-red-600">{phone.batteryTests.gaming}</div>
                              <div className="text-xs text-slate-500 mt-1">Heavy gaming</div>
                            </div>
                          )}
                          {phone.batteryTests.browsing && (
                            <div className="p-4 bg-cyan-50 rounded-lg border-2 border-cyan-200">
                              <div className="text-sm font-semibold text-slate-700 mb-2">🌐 Web Browsing</div>
                              <div className="text-2xl font-bold text-cyan-600">{phone.batteryTests.browsing}</div>
                              <div className="text-xs text-slate-500 mt-1">WiFi browsing</div>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-slate-500">
                        <div className="text-4xl mb-2">🔋</div>
                        <p>Battery test data coming soon!</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Similar Phones */}
        {relatedPhones.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">Similar Phones</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {relatedPhones.map((relatedPhone) => (
                <Link key={relatedPhone._id} href={`/phone/${relatedPhone.slug}`}>
                  <Card className="hover:shadow-lg transition-all border-slate-200 hover:border-cyan-500 h-full">
                    <CardContent className="p-4">
                      <div className="aspect-square bg-slate-50 rounded-lg mb-3 flex items-center justify-center">
                        {relatedPhone.images?.[0] ? (
                          <img 
                            src={relatedPhone.images[0]} 
                            alt={relatedPhone.model}
                            className="w-full h-full object-contain"
                          />
                        ) : (
                          <Smartphone className="w-16 h-16 text-slate-300" />
                        )}
                      </div>
                      <div className="text-xs text-slate-500">{relatedPhone.brandName}</div>
                      <h3 className="font-semibold text-sm line-clamp-2 mb-2 text-slate-800">{relatedPhone.model}</h3>
                      {relatedPhone.price > 0 && (
                        <div className="text-base font-bold text-cyan-600">
                          {formatPrice(relatedPhone.price)}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SpecSection({ title, specs }) {
  if (!specs) return null;
  
  const entries = Object.entries(specs).filter(([key, value]) => 
    value && value !== false && value !== '' && !(Array.isArray(value) && value.length === 0)
  );
  
  if (entries.length === 0) return null;
  
  return (
    <div>
      <h3 className="font-semibold text-lg text-slate-800 mb-3">{title}</h3>
      <div className="space-y-2">
        {entries.map(([key, value]) => (
          <div key={key} className="flex justify-between py-2 border-b border-slate-100 last:border-0">
            <span className="text-slate-600 capitalize text-sm">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
            <span className="font-medium text-slate-800 text-sm text-right">
              {Array.isArray(value) ? value.join(', ') : String(value)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
