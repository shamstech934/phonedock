import connectDB from '@/lib/db';
import Phone from '@/models/Phone';
import Brand from '@/models/Brand';

export default async function sitemap() {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  
  try {
    await connectDB();
    
    // Get all phones
    const phones = await Phone.find({}).select('slug updatedAt').lean();
    
    // Get all brands  
    const brands = await Brand.find({}).select('slug updatedAt').lean();
    
    const phoneUrls = phones.map((phone) => ({
      url: `${baseUrl}/phone/${phone.slug}`,
      lastModified: phone.updatedAt || new Date(),
      changeFrequency: 'weekly',
      priority: 0.8,
    }));
    
    const brandUrls = brands.map((brand) => ({
      url: `${baseUrl}/brands/${brand.slug}`,
      lastModified: brand.updatedAt || new Date(),
      changeFrequency: 'monthly',
      priority: 0.7,
    }));
    
    return [
      {
        url: baseUrl,
        lastModified: new Date(),
        changeFrequency: 'daily',
        priority: 1.0,
      },
      {
        url: `${baseUrl}/phones`,
        lastModified: new Date(),
        changeFrequency: 'daily',
        priority: 0.9,
      },
      {
        url: `${baseUrl}/brands`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.8,
      },
      {
        url: `${baseUrl}/compare`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.7,
      },
      {
        url: `${baseUrl}/news`,
        lastModified: new Date(),
        changeFrequency: 'daily',
        priority: 0.6,
      },
      {
        url: `${baseUrl}/search`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.5,
      },
      ...phoneUrls,
      ...brandUrls,
    ];
  } catch (error) {
    console.error('Error generating sitemap:', error);
    // Return basic sitemap if database fails
    return [
      {
        url: baseUrl,
        lastModified: new Date(),
        changeFrequency: 'daily',
        priority: 1.0,
      },
    ];
  }
}
