'use client'

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Smartphone, Search, Package, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function BrandsPage() {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBrands();
  }, []);

  async function loadBrands() {
    try {
      const response = await fetch('/api/brands');
      const data = await response.json();
      setBrands(data.brands || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading brands:', error);
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-blue-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/" className="text-slate-600 hover:text-blue-600 transition">Home</Link>
              <Link href="/phones" className="text-slate-600 hover:text-blue-600 transition">Phones</Link>
              <Link href="/brands" className="text-slate-800 font-semibold hover:text-blue-600 transition">Brands</Link>
              <Link href="/compare" className="text-slate-600 hover:text-blue-600 transition">Compare</Link>
              <Link href="/news" className="text-slate-600 hover:text-blue-600 transition">News</Link>
            </nav>

            <div className="flex items-center gap-4">
              <Link href="/search">
                <Button variant="ghost" size="sm" className="text-slate-600 hover:text-blue-600">
                  <Search className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Banner */}
      <section className="bg-gradient-to-r from-blue-50 via-sky-50 to-purple-50 border-b">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-xl">
                <Package className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-slate-800">Phone Brands</h1>
                <p className="text-slate-600">Browse smartphones by manufacturer</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="text-sm text-slate-500 mb-6">
          <Link href="/" className="hover:text-blue-600">Home</Link>
          {' / '}
          <span className="text-slate-800">Brands</span>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="text-slate-600">Loading brands...</div>
          </div>
        ) : brands.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Package className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">No brands yet</h3>
            <p className="text-slate-600">Brands will appear here once added</p>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-800 mb-2">All Brands</h2>
              <p className="text-slate-600">Found {brands.length} smartphone manufacturers</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {brands.map((brand) => (
                <Link key={brand._id} href={`/brands/${brand.slug}`}>
                  <Card className="group hover:shadow-xl transition-all border-2 border-slate-200 hover:border-blue-500 h-full">
                    <CardContent className="p-6">
                      <div className="text-center">
                        <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden">
                          {brand.logo ? (
                            <img 
                              src={brand.logo} 
                              alt={brand.name}
                              className="w-full h-full object-contain p-2"
                              loading="lazy"
                            />
                          ) : (
                            <span className="text-3xl font-bold text-blue-600">{brand.name.charAt(0)}</span>
                          )}
                        </div>
                        <h3 className="text-xl font-bold text-slate-800 group-hover:text-blue-600 transition mb-2">
                          {brand.name}
                        </h3>
                        {brand.country && (
                          <p className="text-sm text-slate-500 mb-3">{brand.country}</p>
                        )}
                        {brand.description && (
                          <p className="text-sm text-slate-600 line-clamp-2">{brand.description}</p>
                        )}
                        <div className="mt-4 flex items-center justify-center text-blue-600 group-hover:gap-2 transition-all">
                          <span className="text-sm font-semibold">View Phones</span>
                          <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
