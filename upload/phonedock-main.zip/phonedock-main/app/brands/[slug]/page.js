'use client'

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, Search, ArrowLeft, Star, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function BrandDetailPage() {
  const params = useParams();
  const [brand, setBrand] = useState(null);
  const [phones, setPhones] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (params.slug) {
      loadBrand(params.slug);
    }
  }, [params.slug]);

  async function loadBrand(slug) {
    try {
      const response = await fetch(`/api/brands/${slug}`);
      const data = await response.json();
      
      if (data.error) {
        setLoading(false);
        return;
      }
      
      setBrand(data.brand);
      setPhones(data.phones || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading brand:', error);
      setLoading(false);
    }
  }

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-xl text-slate-600">Loading...</div>
      </div>
    );
  }

  if (!brand) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Brand not found</h2>
          <Link href="/brands">
            <Button className="bg-blue-600 hover:bg-blue-700">View All Brands</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-blue-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            <Link href="/brands">
              <Button variant="ghost" className="text-slate-600 hover:text-blue-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                All Brands
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Brand Header */}
      <section className="bg-gradient-to-r from-blue-50 via-sky-50 to-purple-50 border-b">
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center shadow-lg overflow-hidden">
              {brand.logo ? (
                <img 
                  src={brand.logo} 
                  alt={brand.name}
                  className="w-full h-full object-contain p-3"
                />
              ) : (
                <span className="text-5xl font-bold text-blue-600">{brand.name.charAt(0)}</span>
              )}
            </div>
            <div>
              <h1 className="text-4xl font-bold text-slate-800 mb-2">{brand.name}</h1>
              {brand.country && (
                <p className="text-lg text-slate-600 mb-2">{brand.country}</p>
              )}
              {brand.description && (
                <p className="text-slate-600">{brand.description}</p>
              )}
              <div className="mt-4">
                <Badge className="bg-blue-600 text-white">{phones.length} Phones Available</Badge>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="text-sm text-slate-500 mb-6">
          <Link href="/" className="hover:text-blue-600">Home</Link>
          {' / '}
          <Link href="/brands" className="hover:text-blue-600">Brands</Link>
          {' / '}
          <span className="text-slate-800">{brand.name}</span>
        </div>

        {phones.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Package className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">No phones yet</h3>
            <p className="text-slate-600">No phones from {brand.name} have been added yet</p>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-800 mb-2">{brand.name} Phones</h2>
              <p className="text-slate-600">{phones.length} phones available</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {phones.map((phone) => (
                <Link key={phone._id} href={`/phone/${phone.slug}`}>
                  <Card className="group hover:shadow-xl transition-all border-2 border-slate-200 hover:border-blue-500 h-full">
                    <CardContent className="p-4">
                      <div className="aspect-square bg-slate-50 rounded-lg mb-3 flex items-center justify-center overflow-hidden">
                        {phone.images?.[0] ? (
                          <img 
                            src={phone.images[0]} 
                            alt={phone.model}
                            className="w-full h-full object-contain group-hover:scale-110 transition-transform"
                          />
                        ) : (
                          <Smartphone className="w-16 h-16 text-slate-300" />
                        )}
                      </div>
                      <div className="space-y-2">
                        <h3 className="font-bold text-slate-800 line-clamp-2 text-sm group-hover:text-blue-600 transition">
                          {phone.model}
                        </h3>
                        {phone.price > 0 && (
                          <div className="text-lg font-bold text-blue-600">
                            {formatPrice(phone.price)}
                          </div>
                        )}
                        <div className="flex flex-wrap gap-1">
                          {phone.trending && <Badge className="bg-red-500 text-white text-xs">Hot</Badge>}
                          {phone.ptaApproved && <Badge variant="outline" className="text-green-600 border-green-600 text-xs">PTA</Badge>}
                        </div>
                        {phone.ratings?.overall > 0 && (
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            <span className="font-semibold text-slate-700 text-sm">{phone.ratings.overall.toFixed(1)}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
