'use client'

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, Smartphone, TrendingUp, Clock, DollarSign, Star, ChevronRight, Zap, Award, Battery, Shield, Truck, CheckCircle2, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function HomePage() {
  const [phones, setPhones] = useState([]);
  const [trendingPhones, setTrendingPhones] = useState([]);
  const [featuredPhones, setFeaturedPhones] = useState([]);
  const [bestCameraPhones, setBestCameraPhones] = useState([]);
  const [bestGamingPhones, setBestGamingPhones] = useState([]);
  const [bestBatteryPhones, setBestBatteryPhones] = useState([]);
  const [upcomingPhones, setUpcomingPhones] = useState([]);
  const [brands, setBrands] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      
      const [brandsRes, phonesRes, trendingRes, featuredRes, cameraRes, gamingRes, batteryRes, upcomingRes] = await Promise.all([
        fetch('/api/brands'),
        fetch('/api/phones?limit=8'),
        fetch('/api/phones?trending=true&limit=6'),
        fetch('/api/phones?featured=true&limit=4'),
        fetch('/api/phones?sortBy=camera&limit=4'),
        fetch('/api/phones?sortBy=gaming&limit=4'),
        fetch('/api/phones?sortBy=battery&limit=4'),
        fetch('/api/phones?upcoming=true&limit=4')
      ]);
      
      const brandsData = await brandsRes.json();
      const phonesData = await phonesRes.json();
      const trendingData = await trendingRes.json();
      const featuredData = await featuredRes.json();
      const cameraData = await cameraRes.json();
      const gamingData = await gamingRes.json();
      const batteryData = await batteryRes.json();
      const upcomingData = await upcomingRes.json();
      
      setBrands(brandsData.brands || []);
      setPhones(phonesData.phones || []);
      setTrendingPhones(trendingData.phones || []);
      setFeaturedPhones(featuredData.phones || []);
      setBestCameraPhones(cameraData.phones || []);
      setBestGamingPhones(gamingData.phones || []);
      setBestBatteryPhones(batteryData.phones || []);
      setUpcomingPhones(upcomingData.phones || []);
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
    }
  }

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`;
    }
  };

  const priceCategories = [
    { label: 'Budget Phones', desc: 'Under 20K', min: 0, max: 20000, gradient: 'from-emerald-500 to-teal-500' },
    { label: 'Mid-Range', desc: '20K - 40K', min: 20000, max: 40000, gradient: 'from-blue-500 to-cyan-500' },
    { label: 'Premium', desc: '40K - 60K', min: 40000, max: 60000, gradient: 'from-purple-500 to-pink-500' },
    { label: 'Flagship', desc: '60K - 100K', min: 60000, max: 100000, gradient: 'from-orange-500 to-red-500' },
    { label: 'Ultra Premium', desc: 'Above 100K', min: 100000, max: 999999999, gradient: 'from-amber-500 to-yellow-500' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
        <header className="bg-white shadow-sm">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-2">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-xl animate-pulse">
                  <Smartphone className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">PhoneDock</span>
              </div>
            </div>
          </div>
        </header>
        <div className="container mx-auto px-4 py-12">
          <div className="flex flex-col items-center justify-center min-h-[400px]">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mb-4"></div>
            <p className="text-slate-600 font-medium">Loading PhoneDock...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-purple-600 text-white py-2 overflow-hidden">
        <div className="animate-marquee whitespace-nowrap inline-block">
          <span className="mx-8">🔥 iPhone 15 Pro Max Now Available in Pakistan</span>
          <span className="mx-8">⚡ Samsung Galaxy S24 Ultra - Best Camera Phone 2024</span>
          <span className="mx-8">🎮 OnePlus 12 - Gaming Beast at Rs 249,999</span>
          <span className="mx-8">📸 Google Pixel 8 Pro - Photography King</span>
          <span className="mx-8">🔋 Xiaomi 14 Pro - All Day Battery Life</span>
          <span className="mx-8">✅ Check PTA Approved Phones - Latest Updates</span>
          <span className="mx-8">🔥 iPhone 15 Pro Max Now Available in Pakistan</span>
          <span className="mx-8">⚡ Samsung Galaxy S24 Ultra - Best Camera Phone 2024</span>
        </div>
      </div>

      {/* Trust Bar */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between text-sm py-2">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-slate-700">Fast Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-slate-700">PTA Verified</span>
              </div>
            </div>
            <div className="hidden md:block font-medium text-slate-700">Pakistan's Most Trusted Phone Database</div>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-xl">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">PhoneDock</span>
                <div className="text-xs text-slate-500 -mt-1">Smart Choice</div>
              </div>
            </Link>
            
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/" className="text-slate-700 font-semibold hover:text-blue-600 transition">Home</Link>
              <Link href="/phones" className="text-slate-600 hover:text-blue-600 transition">Phones</Link>
              <Link href="/brands" className="text-slate-600 hover:text-blue-600 transition">Brands</Link>
              <Link href="/compare" className="text-slate-600 hover:text-blue-600 transition">Compare</Link>
              <Link href="/news" className="text-slate-600 hover:text-blue-600 transition">News</Link>
            </nav>

            <div className="flex items-center gap-3">
              <Link href="/search">
                <Button variant="ghost" size="sm" className="text-slate-600 hover:text-blue-600">
                  <Search className="w-5 h-5" />
                </Button>
              </Link>
              <Link href="/admin/login">
                <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg">
                  Admin
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-sky-50 to-purple-50"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMzYjgyZjYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yIDItNCAyLTRzMiAyIDIgNHYxMmMwIDIgMiA0IDIgNHMyLTIgMi00di0xMmMwLTIgMi00IDItNHMyIDIgMiA0djEyYzAgMiAyIDQgMiA0czItMiAyLTR2LTEyYzAtMiAyLTQgMi00czIgMiAyIDR2MTJjMCAyIDIgNCAyIDRzMi0yIDItNFYzNGMwLTIgMi00IDItNHMyIDIgMiA0djEyYzAgMiAyIDQgMiA0czItMiAyLTRWMzRjMC0yIDItNCAyLTRzMiAyIDIgNHYxMmMwIDIgMiA0IDIgNHMyLTIgMi00VjM0YzAtMiAyLTQgMi00czIgMiAyIDR2MTJjMCAyIDIgNCAyIDRzMi0yIDItNFYzNGMwLTIgMi00IDItNHMyIDIgMiA0djEyYzAgMiAyIDQgMiA0czItMiAyLTR2LTEyYzAtMiAyLTQgMi00czIgMiAyIDR2MTJjMCAyIDIgNCAyIDQiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
        
        <div className="container mx-auto px-4 py-12 relative">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-md">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-600"></span>
                </span>
                <span className="text-sm font-semibold text-slate-700">Pakistan ki #1 Phone Database</span>
              </div>
              
              <h1 className="text-5xl md:text-6xl font-extrabold leading-tight">
                <span className="text-slate-800">Apna Dream Phone</span>
                <br />
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Dhundein Easily!</span>
              </h1>
              
              <p className="text-lg text-slate-600">
                Complete specs, latest prices in Pakistan, PTA status, aur honest reviews - sab ek jagah!
              </p>
              
              <form onSubmit={handleSearch} className="flex gap-2">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    type="text"
                    placeholder="Phone name, brand ya chipset search karein..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-14 text-base bg-white border-2 border-slate-200 focus:border-blue-500 shadow-lg rounded-xl"
                  />
                </div>
                <Button type="submit" className="h-14 px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-xl rounded-xl font-semibold">
                  Search
                </Button>
              </form>

              <div className="flex flex-wrap gap-3">
                <Link href="/phones?trending=true">
                  <Button variant="outline" className="border-2 border-blue-200 text-blue-600 hover:bg-blue-50 rounded-full">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Trending
                  </Button>
                </Link>
                <Link href="/phones?featured=true">
                  <Button variant="outline" className="border-2 border-purple-200 text-purple-600 hover:bg-purple-50 rounded-full">
                    <Award className="w-4 h-4 mr-2" />
                    Featured
                  </Button>
                </Link>
                <Link href="/compare">
                  <Button variant="outline" className="border-2 border-slate-200 text-slate-600 hover:bg-slate-50 rounded-full">
                    <Zap className="w-4 h-4 mr-2" />
                    Compare
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="hidden md:block relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-purple-400 rounded-3xl blur-3xl opacity-20"></div>
              <div className="relative bg-white rounded-3xl shadow-2xl p-8">
                <img 
                  src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600" 
                  alt="Smartphones"
                  className="rounded-2xl"
                />
                <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-2xl shadow-xl">
                  <div className="text-sm font-semibold">4000+ Phones</div>
                  <div className="text-xs opacity-90">Available</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <div className="bg-white py-8 border-y">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex items-center justify-center gap-3 text-slate-700">
              <div className="bg-blue-100 p-3 rounded-xl">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="font-bold">PTA Verified</div>
                <div className="text-xs text-slate-500">Official Status</div>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3 text-slate-700">
              <div className="bg-blue-100 p-3 rounded-xl">
                <CheckCircle2 className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="font-bold">Accurate Info</div>
                <div className="text-xs text-slate-500">100% Verified</div>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3 text-slate-700">
              <div className="bg-purple-100 p-3 rounded-xl">
                <Star className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <div className="font-bold">Expert Reviews</div>
                <div className="text-xs text-slate-500">Honest Ratings</div>
              </div>
            </div>
            <div className="flex items-center justify-center gap-3 text-slate-700">
              <div className="bg-green-100 p-3 rounded-xl">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="font-bold">Daily Updates</div>
                <div className="text-xs text-slate-500">Latest Prices</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Price Categories */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-slate-800 mb-2">Apne Budget Se Chune</h2>
            <p className="text-slate-600">Har budget ke liye best phones</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {priceCategories.map((category) => (
              <Link
                key={category.label}
                href={`/phones?minPrice=${category.min}&maxPrice=${category.max}`}
                className="group relative overflow-hidden bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all border-2 border-transparent hover:border-blue-200"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${category.gradient} opacity-5 group-hover:opacity-10 transition-opacity`}></div>
                <div className="relative text-center">
                  <div className="text-2xl font-bold text-slate-800 mb-1">{category.label}</div>
                  <div className="text-sm font-medium text-slate-600">{category.desc}</div>
                  <div className="mt-3 inline-block bg-gradient-to-r from-blue-100 to-purple-100 text-blue-600 px-3 py-1 rounded-full text-xs font-semibold">
                    View Phones
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Phones */}
        {featuredPhones.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2">Editor's Choice</h2>
                <p className="text-slate-600">Hamari top picks aap ke liye</p>
              </div>
              <Link href="/phones?featured=true">
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {featuredPhones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} featured />
              ))}
            </div>
          </section>
        )}

        {/* Trending Phones */}
        {trendingPhones.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2">Is Waqt Trending</h2>
                <p className="text-slate-600">Sab se zyada popular phones</p>
              </div>
              <Link href="/phones?trending=true">
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {trendingPhones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} compact />
              ))}
            </div>
          </section>
        )}

        {/* Best Camera Phones */}
        {bestCameraPhones.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center gap-3">
                  <Camera className="w-8 h-8 text-blue-600" />
                  Best Camera Phones
                </h2>
                <p className="text-slate-600">Photography lovers ke liye perfect</p>
              </div>
              <Link href="/phones?sortBy=camera">
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {bestCameraPhones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} showBadge="Camera" />
              ))}
            </div>
          </section>
        )}

        {/* Best Gaming Phones */}
        {bestGamingPhones.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center gap-3">
                  <Zap className="w-8 h-8 text-purple-600" />
                  Best Gaming Phones
                </h2>
                <p className="text-slate-600">Gamers ki pehli pasand</p>
              </div>
              <Link href="/phones?sortBy=gaming">
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {bestGamingPhones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} showBadge="Gaming" />
              ))}
            </div>
          </section>
        )}

        {/* Best Battery Phones */}
        {bestBatteryPhones.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center gap-3">
                  <Battery className="w-8 h-8 text-green-600" />
                  Best Battery Phones
                </h2>
                <p className="text-slate-600">All-day battery life guaranteed</p>
              </div>
              <Link href="/phones?sortBy=battery">
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {bestBatteryPhones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} showBadge="Battery" />
              ))}
            </div>
          </section>
        )}

        {/* Latest Phones */}
        <section className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2">Latest Arrivals</h2>
              <p className="text-slate-600">Naye launch hone wale phones</p>
            </div>
            <Link href="/phones">
              <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                View All <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>
          {phones.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {phones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} />
              ))}
            </div>
          ) : (
            <Card className="border-2 border-dashed border-slate-200">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Smartphone className="w-16 h-16 text-slate-300 mb-4" />
                <h3 className="text-lg font-semibold text-slate-700 mb-2">No Phones Found</h3>
                <p className="text-slate-500 text-center">Phones coming soon! Check back later.</p>
              </CardContent>
            </Card>
          )}
        </section>

        {/* Upcoming Phones */}
        {upcomingPhones.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2 flex items-center gap-3">
                  <Clock className="w-8 h-8 text-cyan-600" />
                  Upcoming Phones
                </h2>
                <p className="text-slate-600">Jald aanay wale naye phones</p>
              </div>
              <Link href="/phones?upcoming=true">
                <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                  View All <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {upcomingPhones.map((phone) => (
                <PhoneCard key={phone._id} phone={phone} showBadge="Upcoming" />
              ))}
            </div>
          </section>
        )}

        {/* Popular Brands */}
        {brands.length > 0 && (
          <section className="mb-16">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-slate-800 mb-2">Popular Brands</h2>
              <p className="text-slate-600">Apni pasandeeda brand se choose karein</p>
            </div>
            <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
              {brands.slice(0, 8).map((brand) => (
                <Link
                  key={brand._id}
                  href={`/brands/${brand.slug}`}
                  className="group bg-white rounded-2xl p-4 shadow-md hover:shadow-xl transition-all border-2 border-transparent hover:border-blue-200 text-center"
                >
                  <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden">
                    {brand.logo ? (
                      <img 
                        src={brand.logo} 
                        alt={brand.name}
                        className="w-full h-full object-contain p-1"
                        loading="lazy"
                      />
                    ) : (
                      <span className="text-xl font-bold text-blue-600">{brand.name.charAt(0)}</span>
                    )}
                  </div>
                  <div className="font-semibold text-slate-800 text-sm group-hover:text-blue-600 transition">{brand.name}</div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-slate-900 to-slate-800 text-white mt-16">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-xl">
                  <Smartphone className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">PhoneDock</span>
              </div>
              <p className="text-slate-400 text-sm">
                Pakistan's most trusted smartphone database. Har phone ki complete details aur latest prices.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-3 text-blue-400">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/phones" className="text-slate-400 hover:text-blue-400 transition">All Phones</Link></li>
                <li><Link href="/brands" className="text-slate-400 hover:text-blue-400 transition">Brands</Link></li>
                <li><Link href="/compare" className="text-slate-400 hover:text-blue-400 transition">Compare</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3 text-blue-400">Categories</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/phones?featured=true" className="text-slate-400 hover:text-blue-400 transition">Featured</Link></li>
                <li><Link href="/phones?trending=true" className="text-slate-400 hover:text-blue-400 transition">Trending</Link></li>
                <li><Link href="/phones?upcoming=true" className="text-slate-400 hover:text-blue-400 transition">Upcoming</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3 text-blue-400">More</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/news" className="text-slate-400 hover:text-blue-400 transition">News</Link></li>
                <li><Link href="/admin/login" className="text-slate-400 hover:text-blue-400 transition">Admin</Link></li>
              </ul>
            </div>
          </div>
          <div className="pt-6 border-t border-slate-700 text-center text-sm text-slate-400">
            <p>&copy; 2025 PhoneDock. All rights reserved. Made with ❤️ in Pakistan</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function PhoneCard({ phone, featured = false, compact = false, showBadge = null }) {
  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const badgeConfig = {
    'Camera': { color: 'from-blue-500 to-cyan-500', icon: '📸', text: 'CAMERA' },
    'Gaming': { color: 'from-purple-500 to-pink-500', icon: '🎮', text: 'GAMING' },
    'Battery': { color: 'from-green-500 to-emerald-500', icon: '🔋', text: 'BATTERY' },
    'Upcoming': { color: 'from-cyan-500 to-blue-500', icon: '⏰', text: 'UPCOMING' }
  };

  return (
    <Link href={`/phone/${phone.slug}`}>
      <Card className={`group hover:shadow-2xl transition-all duration-300 border-2 border-slate-100 hover:border-blue-200 h-full overflow-hidden rounded-2xl ${
        featured ? 'ring-2 ring-blue-200' : ''
      }`}>
        <CardContent className={compact ? 'p-3' : 'p-4'}>
          <div className={`relative aspect-square bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl mb-3 flex items-center justify-center overflow-hidden ${
            compact ? 'p-2' : 'p-4'
          }`}>
            {phone.images?.[0] ? (
              <img 
                src={phone.images[0]} 
                alt={phone.model}
                className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-300"
                loading="lazy"
              />
            ) : (
              <Smartphone className={`text-slate-300 ${compact ? 'w-12 h-12' : 'w-20 h-20'}`} />
            )}
            {phone.trending && !showBadge && (
              <div className="absolute top-2 right-2 bg-gradient-to-r from-red-500 to-pink-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
                <TrendingUp className="w-3 h-3" />
                HOT
              </div>
            )}
            {featured && !showBadge && (
              <div className="absolute top-2 left-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
                <Award className="w-3 h-3" />
                PICK
              </div>
            )}
            {showBadge && badgeConfig[showBadge] && (
              <div className={`absolute top-2 right-2 bg-gradient-to-r ${badgeConfig[showBadge].color} text-white px-2 py-1 rounded-full text-xs font-bold shadow-lg`}>
                {badgeConfig[showBadge].icon} {badgeConfig[showBadge].text}
              </div>
            )}
          </div>
          
          <div className="space-y-2">
            <div className={`text-slate-500 uppercase tracking-wide font-medium ${compact ? 'text-xs' : 'text-xs'}`}>{phone.brandName}</div>
            <h3 className={`font-bold text-slate-800 line-clamp-2 group-hover:text-blue-600 transition ${compact ? 'text-xs' : 'text-sm'}`}>
              {phone.model}
            </h3>
            
            {/* Quick Specs - Only for non-compact cards */}
            {!compact && phone.specs && (
              <div className="space-y-1 py-2 border-t border-slate-100">
                {phone.specs.processor?.chipset && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <Zap className="w-3.5 h-3.5 text-purple-500 flex-shrink-0" />
                    <span className="truncate font-medium">{phone.specs.processor.chipset.split('(')[0].trim()}</span>
                  </div>
                )}
                {phone.specs.memory?.ram && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <div className="w-3.5 h-3.5 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-blue-500">RAM</span>
                    </div>
                    <span className="font-medium">{phone.specs.memory.ram}</span>
                  </div>
                )}
                {phone.specs.battery?.capacity && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <Battery className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                    <span className="font-medium">{phone.specs.battery.capacity}</span>
                  </div>
                )}
                {phone.specs.camera?.main && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <Camera className="w-3.5 h-3.5 text-cyan-500 flex-shrink-0" />
                    <span className="truncate font-medium">{phone.specs.camera.main.split(',')[0]}</span>
                  </div>
                )}
              </div>
            )}
            
            <div className="flex items-center justify-between pt-2">
              {phone.price > 0 && (
                <div className={`font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent ${compact ? 'text-sm' : 'text-base'}`}>
                  {formatPrice(phone.price)}
                </div>
              )}
              {phone.ratings?.overall > 0 && (
                <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-full">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span className="text-xs font-bold text-amber-700">{phone.ratings.overall.toFixed(1)}</span>
                </div>
              )}
            </div>
            
            {!compact && (
              <div className="flex flex-wrap gap-1 pt-1">
                {phone.ptaApproved && (
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-200 text-xs border-0">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    PTA
                  </Badge>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
