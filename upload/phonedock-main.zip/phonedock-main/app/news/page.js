'use client'

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Smartphone, Search, Newspaper, Calendar, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function NewsPage() {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNews();
  }, []);

  async function loadNews() {
    try {
      const response = await fetch('/api/news');
      const data = await response.json();
      setNews(data.news || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading news:', error);
      setLoading(false);
    }
  }

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-PK', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getCategoryColor = (category) => {
    const colors = {
      launch: 'bg-blue-100 text-blue-700',
      rumor: 'bg-purple-100 text-purple-700',
      review: 'bg-green-100 text-green-700',
      update: 'bg-orange-100 text-orange-700',
      other: 'bg-gray-100 text-gray-700',
    };
    return colors[category] || colors.other;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-cyan-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/" className="text-slate-600 hover:text-cyan-600 transition">Home</Link>
              <Link href="/phones" className="text-slate-600 hover:text-cyan-600 transition">Phones</Link>
              <Link href="/brands" className="text-slate-600 hover:text-cyan-600 transition">Brands</Link>
              <Link href="/compare" className="text-slate-600 hover:text-cyan-600 transition">Compare</Link>
              <Link href="/news" className="text-slate-800 font-semibold hover:text-cyan-600 transition">News</Link>
            </nav>

            <div className="flex items-center gap-4">
              <Link href="/search">
                <Button variant="ghost" size="sm" className="text-slate-600 hover:text-cyan-600">
                  <Search className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Banner */}
      <section className="bg-gradient-to-r from-yellow-50 via-amber-50 to-yellow-50 border-b">
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center gap-4">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-xl">
              <Newspaper className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-slate-800">Latest News</h1>
              <p className="text-lg text-slate-600">Stay updated with smartphone industry news</p>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="text-sm text-slate-500 mb-6">
          <Link href="/" className="hover:text-cyan-600">Home</Link>
          {' / '}
          <span className="text-slate-800">News</span>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="text-slate-600">Loading news...</div>
          </div>
        ) : news.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Newspaper className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">No news yet</h3>
            <p className="text-slate-600">News articles will appear here once published</p>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-800 mb-2">All Articles</h2>
              <p className="text-slate-600">{news.length} articles published</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {news.map((article) => (
                <Card key={article._id} className="group hover:shadow-xl transition-all border-2 border-slate-200 hover:border-cyan-500 overflow-hidden">
                  <CardContent className="p-0">
                    {article.image && (
                      <div className="aspect-video bg-slate-100 overflow-hidden">
                        <img 
                          src={article.image} 
                          alt={article.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                    )}
                    <div className="p-6">
                      <div className="flex items-center gap-2 mb-3">
                        <Badge className={getCategoryColor(article.category)}>
                          <Tag className="w-3 h-3 mr-1" />
                          {article.category}
                        </Badge>
                        <div className="flex items-center text-xs text-slate-500">
                          <Calendar className="w-3 h-3 mr-1" />
                          {formatDate(article.createdAt)}
                        </div>
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 group-hover:text-cyan-600 transition mb-3 line-clamp-2">
                        {article.title}
                      </h3>
                      {article.excerpt && (
                        <p className="text-slate-600 text-sm line-clamp-3 mb-4">{article.excerpt}</p>
                      )}
                      {article.author && (
                        <p className="text-xs text-slate-500">By {article.author}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
