'use client'

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, Plus, Edit, Trash2, ArrowLeft, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function AdminBrandsPage() {
  const router = useRouter();
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBrand, setEditingBrand] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    logo: '',
    country: '',
    description: '',
  });

  useEffect(() => {
    checkAuth();
    loadBrands();
  }, []);

  function checkAuth() {
    const token = localStorage.getItem('phonedock_token');
    if (!token) {
      router.push('/admin/login');
    }
  }

  async function loadBrands() {
    try {
      const response = await fetch('/api/brands');
      const data = await response.json();
      setBrands(data.brands || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading brands:', error);
      setLoading(false);
    }
  }

  function handleOpenDialog(brand = null) {
    if (brand) {
      setEditingBrand(brand);
      setFormData(brand);
    } else {
      setEditingBrand(null);
      setFormData({
        name: '',
        slug: '',
        logo: '',
        country: '',
        description: '',
      });
    }
    setDialogOpen(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    
    try {
      const token = localStorage.getItem('phonedock_token');
      const url = editingBrand 
        ? `/api/admin/brands/${editingBrand._id}`
        : '/api/admin/brands';
      const method = editingBrand ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save brand');
      }
      
      setDialogOpen(false);
      loadBrands();
    } catch (error) {
      alert('Error: ' + error.message);
    }
  }

  async function handleDelete(brandId) {
    if (!confirm('Are you sure? This will not delete associated phones.')) return;
    
    try {
      const token = localStorage.getItem('phonedock_token');
      await fetch(`/api/admin/brands/${brandId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      loadBrands();
    } catch (error) {
      alert('Error deleting brand');
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-black text-white border-b-4 border-yellow-400">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/admin" className="flex items-center gap-2">
              <ArrowLeft className="w-5 h-5" />
              <Smartphone className="w-8 h-8 text-yellow-400" />
              <span className="text-2xl font-bold">
                Phone<span className="text-yellow-400">Dock</span>
              </span>
            </Link>
            <h1 className="text-xl font-semibold">Manage Brands</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold">Brands</h2>
            <p className="text-gray-600">Total: {brands.length}</p>
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-yellow-400 text-black hover:bg-yellow-500"
                onClick={() => handleOpenDialog()}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Brand
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingBrand ? 'Edit Brand' : 'Add New Brand'}</DialogTitle>
                <DialogDescription>
                  Fill in the brand details below
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Brand Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                    placeholder="e.g., Samsung"
                  />
                </div>

                <div>
                  <Label>Slug (URL)</Label>
                  <Input
                    value={formData.slug}
                    onChange={(e) => setFormData({...formData, slug: e.target.value})}
                    required
                    placeholder="e.g., samsung"
                  />
                </div>

                <div>
                  <Label>Logo URL (optional)</Label>
                  <Input
                    value={formData.logo}
                    onChange={(e) => setFormData({...formData, logo: e.target.value})}
                    placeholder="https://example.com/logo.png"
                  />
                </div>

                <div>
                  <Label>Country (optional)</Label>
                  <Input
                    value={formData.country}
                    onChange={(e) => setFormData({...formData, country: e.target.value})}
                    placeholder="e.g., South Korea"
                  />
                </div>

                <div>
                  <Label>Description (optional)</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    placeholder="Brief description of the brand"
                  />
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-yellow-400 text-black hover:bg-yellow-500">
                    {editingBrand ? 'Update' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Brands List */}
        {loading ? (
          <div className="text-center py-12">Loading brands...</div>
        ) : brands.length === 0 ? (
          <Card className="p-12 text-center">
            <Package className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl font-semibold mb-2">No brands yet</h3>
            <p className="text-gray-600 mb-4">Add your first brand to get started</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {brands.map((brand) => (
              <Card key={brand._id} className="hover:shadow-lg transition-all">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-bold text-xl mb-1">{brand.name}</h3>
                      <div className="text-sm text-gray-600 mb-2">/{brand.slug}</div>
                      {brand.country && (
                        <div className="text-sm text-gray-500">{brand.country}</div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleOpenDialog(brand)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(brand._id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
