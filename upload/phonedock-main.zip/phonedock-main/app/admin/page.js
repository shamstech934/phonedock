'use client'

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, Plus, BarChart3, TrendingUp, Package, Newspaper, LogOut, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function AdminDashboard() {
  const router = useRouter();
  const [admin, setAdmin] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    checkAuth();
    loadStats();
  }, []);

  function checkAuth() {
    const token = localStorage.getItem('phonedock_token');
    const adminData = localStorage.getItem('phonedock_admin');
    
    if (!token || !adminData) {
      router.push('/admin/login');
      return;
    }
    
    setAdmin(JSON.parse(adminData));
  }

  async function loadStats() {
    try {
      const token = localStorage.getItem('phonedock_token');
      const response = await fetch('/api/admin/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error loading stats:', error);
    } finally {
      setLoading(false);
    }
  }

  function handleLogout() {
    localStorage.removeItem('phonedock_token');
    localStorage.removeItem('phonedock_admin');
    router.push('/admin/login');
  }

  if (!admin) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-black text-white border-b-4 border-yellow-400">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-8 h-8 text-yellow-400" />
              <span className="text-2xl font-bold">
                Phone<span className="text-yellow-400">Dock</span>
              </span>
            </Link>
            
            <div className="flex items-center gap-4">
              <span className="hidden md:inline text-sm">Welcome, {admin.username}</span>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
                className="border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage your PhoneDock platform</p>
        </div>

        {/* Stats Cards */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-gray-600">Loading stats...</div>
          </div>
        ) : stats ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="border-l-4 border-l-yellow-400">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Total Phones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats.totalPhones}</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-blue-400">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Total Brands</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats.totalBrands}</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-400">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Trending Phones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats.trendingPhones}</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-400">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">News Articles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stats.totalNews}</div>
              </CardContent>
            </Card>
          </div>
        ) : null}

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link href="/admin/phones">
            <Card className="hover:shadow-lg transition-all cursor-pointer border-2 hover:border-yellow-400 h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-yellow-100 rounded-lg">
                    <Smartphone className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div>
                    <CardTitle>Manage Phones</CardTitle>
                    <CardDescription>Add, edit, or delete phones</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/admin/brands">
            <Card className="hover:shadow-lg transition-all cursor-pointer border-2 hover:border-yellow-400 h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <Package className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <CardTitle>Manage Brands</CardTitle>
                    <CardDescription>Add or edit phone brands</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/admin/news">
            <Card className="hover:shadow-lg transition-all cursor-pointer border-2 hover:border-yellow-400 h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <Newspaper className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <CardTitle>Manage News</CardTitle>
                    <CardDescription>Create and publish articles</CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>
          </Link>
        </div>

        {/* Getting Started */}
        {stats && stats.totalPhones === 0 && (
          <Alert className="mt-8 border-yellow-400 bg-yellow-50">
            <AlertDescription>
              <div className="font-semibold mb-2">🚀 Getting Started</div>
              <p className="mb-2">Welcome to PhoneDock! To get started:</p>
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>First, add some phone brands</li>
                <li>Then add phones with complete specifications</li>
                <li>Publish news articles to engage visitors</li>
              </ol>
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
}
