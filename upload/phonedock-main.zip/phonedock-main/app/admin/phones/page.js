'use client'

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, Plus, Edit, Trash2, Search, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';

export default function AdminPhonesPage() {
  const router = useRouter();
  const [phones, setPhones] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPhone, setEditingPhone] = useState(null);
  const [formData, setFormData] = useState(getInitialFormData());

  useEffect(() => {
    checkAuth();
    loadData();
  }, []);

  function checkAuth() {
    const token = localStorage.getItem('phonedock_token');
    if (!token) {
      router.push('/admin/login');
    }
  }

  async function loadData() {
    try {
      const token = localStorage.getItem('phonedock_token');
      
      // Load brands
      const brandsRes = await fetch('/api/brands');
      const brandsData = await brandsRes.json();
      setBrands(brandsData.brands || []);
      
      // Load phones
      const phonesRes = await fetch('/api/admin/phones', {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const phonesData = await phonesRes.json();
      setPhones(phonesData.phones || []);
      
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
    }
  }

  function getInitialFormData() {
    return {
      brandId: '',
      brandName: '',
      model: '',
      slug: '',
      releaseDate: '',
      price: '',
      ptaApproved: false,
      featured: false,
      trending: false,
      upcoming: false,
      images: '',
      specs: {
        display: { size: '', resolution: '', type: '', refreshRate: '', protection: '' },
        processor: { chipset: '', cpu: '', gpu: '' },
        memory: { ram: '', storage: '', cardSlot: '' },
        camera: { main: '', features: '', video: '', selfie: '' },
        battery: { capacity: '', charging: '', wireless: false },
        connectivity: { network: '', wifi: '', bluetooth: '', nfc: false, usb: '' },
        body: { dimensions: '', weight: '', build: '', sim: '' },
        features: { fingerprint: '', faceUnlock: false, sensors: '', colors: '' },
        os: { name: '', version: '' },
      },
      ratings: { overall: 0, performance: 0, camera: 0, battery: 0, display: 0, value: 0 },
      review: { pros: '', cons: '', summary: '' },
      benchmarks: { antutu: 0, geekbenchSingle: 0, geekbenchMulti: 0 },
    };
  }

  function handleOpenDialog(phone = null) {
    if (phone) {
      setEditingPhone(phone);
      setFormData({
        ...phone,
        images: phone.images?.join(', ') || '',
        specs: {
          ...getInitialFormData().specs,
          ...phone.specs,
          features: {
            ...getInitialFormData().specs.features,
            ...phone.specs?.features,
            colors: phone.specs?.features?.colors?.join(', ') || '',
          },
        },
        review: {
          ...getInitialFormData().review,
          ...phone.review,
          pros: phone.review?.pros?.join('\n') || '',
          cons: phone.review?.cons?.join('\n') || '',
        },
      });
    } else {
      setEditingPhone(null);
      setFormData(getInitialFormData());
    }
    setDialogOpen(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    
    try {
      const token = localStorage.getItem('phonedock_token');
      
      // Find selected brand
      const selectedBrand = brands.find(b => b._id === formData.brandId);
      
      // Prepare data
      const phoneData = {
        ...formData,
        brandName: selectedBrand?.name || '',
        images: formData.images.split(',').map(s => s.trim()).filter(Boolean),
        specs: {
          ...formData.specs,
          features: {
            ...formData.specs.features,
            colors: formData.specs.features.colors.split(',').map(s => s.trim()).filter(Boolean),
          },
        },
        review: {
          ...formData.review,
          pros: formData.review.pros.split('\n').filter(Boolean),
          cons: formData.review.cons.split('\n').filter(Boolean),
        },
        price: parseFloat(formData.price) || 0,
        ratings: {
          overall: parseFloat(formData.ratings.overall) || 0,
          performance: parseFloat(formData.ratings.performance) || 0,
          camera: parseFloat(formData.ratings.camera) || 0,
          battery: parseFloat(formData.ratings.battery) || 0,
          display: parseFloat(formData.ratings.display) || 0,
          value: parseFloat(formData.ratings.value) || 0,
        },
        benchmarks: {
          antutu: parseInt(formData.benchmarks.antutu) || 0,
          geekbenchSingle: parseInt(formData.benchmarks.geekbenchSingle) || 0,
          geekbenchMulti: parseInt(formData.benchmarks.geekbenchMulti) || 0,
        },
      };
      
      const url = editingPhone 
        ? `/api/admin/phones/${editingPhone._id}`
        : '/api/admin/phones';
      const method = editingPhone ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(phoneData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save phone');
      }
      
      setDialogOpen(false);
      loadData();
    } catch (error) {
      alert('Error: ' + error.message);
    }
  }

  async function handleDelete(phoneId) {
    if (!confirm('Are you sure you want to delete this phone?')) return;
    
    try {
      const token = localStorage.getItem('phonedock_token');
      await fetch(`/api/admin/phones/${phoneId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      loadData();
    } catch (error) {
      alert('Error deleting phone');
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-black text-white border-b-4 border-yellow-400">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/admin" className="flex items-center gap-2">
              <ArrowLeft className="w-5 h-5" />
              <Smartphone className="w-8 h-8 text-yellow-400" />
              <span className="text-2xl font-bold">
                Phone<span className="text-yellow-400">Dock</span>
              </span>
            </Link>
            <h1 className="text-xl font-semibold">Manage Phones</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold">Phones</h2>
            <p className="text-gray-600">Total: {phones.length}</p>
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-yellow-400 text-black hover:bg-yellow-500"
                onClick={() => handleOpenDialog()}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Phone
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingPhone ? 'Edit Phone' : 'Add New Phone'}</DialogTitle>
                <DialogDescription>
                  Fill in the phone details below
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Basic Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Brand</Label>
                    <Select 
                      value={formData.brandId} 
                      onValueChange={(value) => setFormData({...formData, brandId: value})}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select brand" />
                      </SelectTrigger>
                      <SelectContent>
                        {brands.map(brand => (
                          <SelectItem key={brand._id} value={brand._id}>
                            {brand.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Model Name</Label>
                    <Input
                      value={formData.model}
                      onChange={(e) => setFormData({...formData, model: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Slug (URL)</Label>
                    <Input
                      value={formData.slug}
                      onChange={(e) => setFormData({...formData, slug: e.target.value})}
                      placeholder="e.g., iphone-15-pro"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label>Price (PKR)</Label>
                    <Input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <Label>Images (comma-separated URLs)</Label>
                  <Textarea
                    value={formData.images}
                    onChange={(e) => setFormData({...formData, images: e.target.value})}
                    placeholder="https://example.com/phone1.jpg, https://example.com/phone2.jpg"
                  />
                </div>

                {/* Flags */}
                <div className="grid grid-cols-4 gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.ptaApproved}
                      onCheckedChange={(checked) => setFormData({...formData, ptaApproved: checked})}
                    />
                    <Label>PTA Approved</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.featured}
                      onCheckedChange={(checked) => setFormData({...formData, featured: checked})}
                    />
                    <Label>Featured</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.trending}
                      onCheckedChange={(checked) => setFormData({...formData, trending: checked})}
                    />
                    <Label>Trending</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.upcoming}
                      onCheckedChange={(checked) => setFormData({...formData, upcoming: checked})}
                    />
                    <Label>Upcoming</Label>
                  </div>
                </div>

                {/* Specs - Display */}
                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-2">Display</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      placeholder="Size (e.g., 6.7 inches)"
                      value={formData.specs.display.size}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, display: {...formData.specs.display, size: e.target.value}}
                      })}
                    />
                    <Input
                      placeholder="Resolution"
                      value={formData.specs.display.resolution}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, display: {...formData.specs.display, resolution: e.target.value}}
                      })}
                    />
                    <Input
                      placeholder="Type (e.g., AMOLED)"
                      value={formData.specs.display.type}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, display: {...formData.specs.display, type: e.target.value}}
                      })}
                    />
                    <Input
                      placeholder="Refresh Rate"
                      value={formData.specs.display.refreshRate}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, display: {...formData.specs.display, refreshRate: e.target.value}}
                      })}
                    />
                  </div>
                </div>

                {/* Specs - Processor */}
                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-2">Processor</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <Input
                      placeholder="Chipset"
                      value={formData.specs.processor.chipset}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, processor: {...formData.specs.processor, chipset: e.target.value}}
                      })}
                    />
                    <Input
                      placeholder="CPU"
                      value={formData.specs.processor.cpu}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, processor: {...formData.specs.processor, cpu: e.target.value}}
                      })}
                    />
                    <Input
                      placeholder="GPU"
                      value={formData.specs.processor.gpu}
                      onChange={(e) => setFormData({
                        ...formData, 
                        specs: {...formData.specs, processor: {...formData.specs.processor, gpu: e.target.value}}
                      })}
                    />
                  </div>
                </div>

                {/* Ratings */}
                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-2">Ratings (0-10)</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs">Overall</Label>
                      <Input
                        type="number"
                        step="0.1"
                        min="0"
                        max="10"
                        value={formData.ratings.overall}
                        onChange={(e) => setFormData({
                          ...formData, 
                          ratings: {...formData.ratings, overall: e.target.value}
                        })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Performance</Label>
                      <Input
                        type="number"
                        step="0.1"
                        min="0"
                        max="10"
                        value={formData.ratings.performance}
                        onChange={(e) => setFormData({
                          ...formData, 
                          ratings: {...formData.ratings, performance: e.target.value}
                        })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Camera</Label>
                      <Input
                        type="number"
                        step="0.1"
                        min="0"
                        max="10"
                        value={formData.ratings.camera}
                        onChange={(e) => setFormData({
                          ...formData, 
                          ratings: {...formData.ratings, camera: e.target.value}
                        })}
                      />
                    </div>
                  </div>
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-yellow-400 text-black hover:bg-yellow-500">
                    {editingPhone ? 'Update' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Phones List */}
        {loading ? (
          <div className="text-center py-12">Loading phones...</div>
        ) : phones.length === 0 ? (
          <Card className="p-12 text-center">
            <Smartphone className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl font-semibold mb-2">No phones yet</h3>
            <p className="text-gray-600 mb-4">Add your first phone to get started</p>
            {brands.length === 0 && (
              <p className="text-sm text-yellow-600">
                Note: You need to add brands first before adding phones
              </p>
            )}
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {phones.map((phone) => (
              <Card key={phone._id} className="hover:shadow-lg transition-all">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="text-sm text-gray-600">{phone.brandName}</div>
                      <h3 className="font-bold">{phone.model}</h3>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleOpenDialog(phone)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(phone._id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {phone.price > 0 && (
                    <div className="text-lg font-semibold text-yellow-600 mb-2">
                      PKR {phone.price.toLocaleString()}
                    </div>
                  )}
                  
                  <div className="flex flex-wrap gap-1">
                    {phone.trending && <Badge className="bg-yellow-400 text-black">Trending</Badge>}
                    {phone.featured && <Badge variant="secondary">Featured</Badge>}
                    {phone.ptaApproved && <Badge variant="outline" className="text-green-600">PTA</Badge>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
