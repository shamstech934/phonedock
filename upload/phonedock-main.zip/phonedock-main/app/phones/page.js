'use client'

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Smartphone, ArrowLeft, Filter, Star, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function PhonesPage() {
  const searchParams = useSearchParams();
  const [phones, setPhones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    brand: searchParams.get('brand') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    trending: searchParams.get('trending') || '',
    featured: searchParams.get('featured') || '',
  });

  useEffect(() => {
    loadPhones();
  }, [filters]);

  async function loadPhones() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (filters.brand) params.append('brand', filters.brand);
      if (filters.minPrice) params.append('minPrice', filters.minPrice);
      if (filters.maxPrice) params.append('maxPrice', filters.maxPrice);
      if (filters.trending) params.append('trending', 'true');
      if (filters.featured) params.append('featured', 'true');
      params.append('limit', '50');
      
      const response = await fetch(`/api/phones?${params}`);
      const data = await response.json();
      setPhones(data.phones || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading phones:', error);
      setLoading(false);
    }
  }

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Smartphone className="w-7 h-7 text-cyan-600" />
              <span className="text-2xl font-bold text-slate-800">PhoneDock</span>
            </Link>
            <Link href="/">
              <Button variant="ghost" className="text-slate-600 hover:text-cyan-600">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">All Phones</h1>
          <p className="text-slate-600">Browse {phones.length} smartphones</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="w-5 h-5 text-cyan-600" />
            <h3 className="font-semibold text-slate-800">Filters</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-slate-600 mb-1 block">Min Price</label>
              <input
                type="number"
                placeholder="Min PKR"
                value={filters.minPrice}
                onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
                className="w-full px-3 py-2 border border-slate-200 rounded-md text-sm"
              />
            </div>
            <div>
              <label className="text-sm text-slate-600 mb-1 block">Max Price</label>
              <input
                type="number"
                placeholder="Max PKR"
                value={filters.maxPrice}
                onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
                className="w-full px-3 py-2 border border-slate-200 rounded-md text-sm"
              />
            </div>
            <div>
              <label className="text-sm text-slate-600 mb-1 block">Show</label>
              <Select value={filters.trending} onValueChange={(value) => setFilters({...filters, trending: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All phones" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All phones</SelectItem>
                  <SelectItem value="true">Trending only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setFilters({brand: '', minPrice: '', maxPrice: '', trending: '', featured: ''})}
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Phones Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-slate-600">Loading phones...</div>
          </div>
        ) : phones.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border">
            <Smartphone className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-800 mb-2">No phones found</h3>
            <p className="text-slate-600">Try adjusting your filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {phones.map((phone) => (
              <Link key={phone._id} href={`/phone/${phone.slug}`}>
                <Card className="hover:shadow-lg transition-all border-slate-200 hover:border-cyan-500 h-full">
                  <CardContent className="p-4">
                    <div className="aspect-square bg-slate-50 rounded-lg mb-3 flex items-center justify-center">
                      {phone.images?.[0] ? (
                        <img src={phone.images[0]} alt={phone.model} className="w-full h-full object-contain" />
                      ) : (
                        <Smartphone className="w-16 h-16 text-slate-300" />
                      )}
                    </div>
                    <div className="text-xs text-slate-500 mb-1">{phone.brandName}</div>
                    <h3 className="font-semibold text-slate-800 line-clamp-2 text-sm mb-2">{phone.model}</h3>
                    {phone.price > 0 && (
                      <div className="text-base font-bold text-cyan-600 mb-2">
                        {formatPrice(phone.price)}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-1">
                      {phone.trending && <Badge className="bg-cyan-100 text-cyan-700 text-xs">Hot</Badge>}
                      {phone.ptaApproved && <Badge variant="outline" className="text-green-600 border-green-600 text-xs">PTA</Badge>}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
